const { ethers } = require("ethers");
require("dotenv").config();

// ABI for VercrowEscrow (Updated)
const ESCROW_ABI = [
    "function submitProof(uint8 _conditionIndex, uint256 _value, bytes32 _proofHash) external"
];

// Load Wallet
const provider = new ethers.JsonRpcProvider(process.env.RPC_URL || "http://127.0.0.1:8545");

// These should be different private keys in production
const deliveryWallet = process.env.DELIVERY_PKEY
    ? new ethers.Wallet(process.env.DELIVERY_PKEY, provider)
    : ethers.Wallet.createRandom(provider);

const qualityWallet = process.env.QUALITY_PKEY
    ? new ethers.Wallet(process.env.QUALITY_PKEY, provider)
    : ethers.Wallet.createRandom(provider);

const submitDeliveryProof = async (escrowAddress, escrowId) => {
    const contract = new ethers.Contract(escrowAddress, ESCROW_ABI, deliveryWallet);
    try {
        // Condition 0: Delivery. Value 1 = Delivered.
        // proofHash: Mock hash using escrowId (or random)
        const proofHash = ethers.id(`delivery-${escrowId || Date.now()}`);
        const tx = await contract.submitProof(0, 1, proofHash);
        await tx.wait();
        return { success: true, hash: tx.hash };
    } catch (error) {
        console.error("Delivery Proof Error:", error);
        throw error;
    }
};

const submitQualityProof = async (escrowAddress, escrowId, score) => {
    const contract = new ethers.Contract(escrowAddress, ESCROW_ABI, qualityWallet);
    try {
        // Condition 1: Quality. Value = score.
        const proofHash = ethers.id(`quality-${escrowId || Date.now()}`);
        const tx = await contract.submitProof(1, score, proofHash);
        await tx.wait();
        return { success: true, hash: tx.hash };
    } catch (error) {
        console.error("Quality Proof Error:", error);
        throw error;
    }
};

module.exports = { submitDeliveryProof, submitQualityProof, deliveryWallet, qualityWallet };
