const { GoogleGenerativeAI } = require("@google/generative-ai");
require("dotenv").config();

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

const parseEscrowTerms = async (prompt) => {
    try {
        if (!process.env.GEMINI_API_KEY || process.env.GEMINI_API_KEY === "mock") {
            console.log("Mocking Gemini Response");
            return {
                item: "Mock Item from AI",
                quantity: 10,
                amount: 1000,
                qualityThreshold: 90,
                deliveryDays: 7,
                email: "demo@vercrow.io",
                sellerName: "Mock Seller Corp",
                notes: "Auto-generated mock notes based on your request."
            };
        }

        const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

        const systemPrompt = `You are an AI that converts natural language escrow requests into structured JSON.
    Input: "Create an escrow for 30 books, price 30000, quality above 85, delivery in 14 days, seller is bob@example.com (Bob Inc)"
    Output JSON: {
      "item": "books",
      "quantity": 30,
      "amount": 30000,
      "qualityThreshold": 85,
      "deliveryDays": 14,
      "email": "bob@example.com",
      "sellerName": "Bob Inc",
      "notes": "Any other details"
    }
    
    Extract the following fields:
    - item (string)
    - quantity (number)
    - amount (number)
    - qualityThreshold (number, 0-100)
    - deliveryDays (number)
    - email (string, optional)
    - sellerName (string, optional)
    - notes (string, optional, summarize any extra context)
    
    Return ONLY JSON. No markdown formatting.
    `;

        const result = await model.generateContent(`${systemPrompt}\n\nInput: "${prompt}"`);
        const response = await result.response;
        const text = response.text();

        // Clean up if markdown is present
        const cleanText = text.replace(/```json/g, "").replace(/```/g, "").trim();

        return JSON.parse(cleanText);
    } catch (error) {
        console.error("Gemini Error:", error);
        throw new Error("Failed to parse terms");
    }
};

module.exports = { parseEscrowTerms };
