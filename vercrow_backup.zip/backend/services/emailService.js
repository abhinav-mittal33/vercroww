const nodemailer = require("nodemailer");
require("dotenv").config();

// Create transporter
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

const sendApprovalEmail = async (sellerEmail, escrowId, terms) => {
  const approvalLink = `http://localhost:3000/approve/${escrowId}`;

  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: sellerEmail,
    subject: "Action Required: Approve Escrow Transaction",
    html: `
      <div style="font-family: Arial, sans-serif; padding: 20px;">
        <h2>New Escrow Request</h2>
        <p>You have a new escrow request waiting for your approval.</p>
        
        <div style="background: #f5f5f5; padding: 15px; border-radius: 5px; margin: 20px 0;">
          <h3>Terms:</h3>
          <ul>
            <li><strong>Item:</strong> ${terms.item}</li>
            <li><strong>Quantity:</strong> ${terms.quantity}</li>
            <li><strong>Amount:</strong> ${terms.amount} USDC</li>
            <li><strong>Delivery:</strong> ${terms.deliveryDays} days</li>
          </ul>
        </div>

        <a href="${approvalLink}" style="background: #4F46E5; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; display: inline-block;">Approve Escrow</a>
        
        <p style="margin-top: 20px; font-size: 12px; color: #666;">If you did not request this, please ignore this email.</p>
      </div>
    `,
  };

  try {
    if (process.env.EMAIL_USER) {
      const info = await transporter.sendMail(mailOptions);
      console.log("Email sent:", info.messageId);
      return info;
    } else {
      console.log("Mock Email Sent:", mailOptions);
      return { messageId: "mock-id" };
    }
  } catch (error) {
    console.error("Email Error:", error);
    throw new Error("Failed to send email");
  }
};

module.exports = { sendApprovalEmail };
