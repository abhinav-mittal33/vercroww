const express = require("express");
const cors = require("cors");
const { parseEscrowTerms } = require("./services/geminiService");
require("dotenv").config();

const app = express();
app.use(cors());
app.use(express.json());

const PORT = 3001;

const { sendApprovalEmail } = require("./services/emailService");
const { submitDeliveryProof, submitQualityProof } = require("./services/agentService");

// API Routes
app.post("/api/parse-escrow", async (req, res) => {
    const { text } = req.body;
    if (!text) return res.status(400).json({ error: "Text is required" });

    try {
        const terms = await parseEscrowTerms(text);
        res.json(terms);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.post("/api/send-approval", async (req, res) => {
    const { sellerEmail, escrowId, terms } = req.body;
    if (!sellerEmail || !escrowId || !terms) {
        return res.status(400).json({ error: "Missing required fields" });
    }

    try {
        const info = await sendApprovalEmail(sellerEmail, escrowId, terms);
        res.json({ success: true, messageId: info.messageId });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.post("/api/confirm-delivery", async (req, res) => {
    const { escrowAddress, escrowId } = req.body;
    try {
        const result = await submitDeliveryProof(escrowAddress, escrowId);
        res.json(result);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.post("/api/submit-quality", async (req, res) => {
    const { escrowAddress, escrowId, score } = req.body;
    try {
        const result = await submitQualityProof(escrowAddress, escrowId, score);
        res.json(result);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

const { JsonRpcProvider, Wallet, parseEther } = require("ethers");

app.post("/api/request-funds", async (req, res) => {
    const { address } = req.body;
    try {
        const provider = new JsonRpcProvider(process.env.RPC_URL);
        const wallet = new Wallet(process.env.FUNDING_PKEY, provider);
        console.log(`Sending 10 ETH to ${address}...`);

        const tx = await wallet.sendTransaction({
            to: address,
            value: parseEther("10.0")
        });
        await tx.wait();

        console.log(`Sent! Tx: ${tx.hash}`);
        res.json({ success: true, hash: tx.hash });
    } catch (error) {
        console.error("Faucet error:", error);
        res.status(500).json({ error: error.message });
    }
});

// Placeholder for other routes
app.get("/", (req, res) => {
    res.send("Vercrow Backend Running");
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
