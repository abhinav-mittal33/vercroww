# 🚀 Zero-to-Live Deployment Guide

Because you asked for "The Fully Working Thing" (Live URL).

## Prereq: The "Hard" Part (Contracts)
You must deploy your contracts to a public testnet (Base Sepolia) so Vercel can talk to them.

### 1. Get Wallet Ready
1.  Open Metamask.
2.  Switch network to **Base Sepolia** (or regular Sepolia).
3.  **Get Test ETH**: Go to [coinbase.com/faucets](https://www.coinbase.com/faucets) and get Base Sepolia ETH.

### 2. Configure Keys
Create a `.env` file in `contracts/`:
```bash
PRIVATE_KEY="YOUR_METAMASK_PRIVATE_KEY"
# (Don't share this!)
```

### 3. Deploy
Run this in your terminal:
```bash
cd contracts
npx hardhat run scripts/deploy.js --network baseSepolia
```

### 4. Update Frontend
The deployment script will print new addresses (e.g., `0x123...`).
Update `frontend/utils/constants.ts`:
```typescript
export const POLICY_VALIDATOR_ADDRESS = "0xNEW_ADDRESS...";
export const VERCROW_ESCROW_IMPLEMENTATION = "0xNEW_ADDRESS...";
export const MOCK_USDC_ADDRESS = "0xNEW_ADDRESS...";
```

---

## Part 2: The "Easy" Part (Frontend)

### 1. Push to GitHub
Commit all your changes and push to your repo.

### 2. Deploy on Vercel
1.  Go to **Vercel.com** -> "Add New Project".
2.  Select your Repo.
3.  **Root Directory**: Click "Edit" and select `frontend`.
4.  **Environment Variables**:
    *   `GEMINI_API_KEY`: `mock` (or your real key).
5.  Click **Deploy**.

🎉 **You now have a `vercrow.vercel.app` link that works globally!**
