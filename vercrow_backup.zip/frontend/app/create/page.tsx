"use client";

import { useState, useEffect } from "react";
import { ethers, BrowserProvider, Contract, parseUnits } from "ethers";
import Navbar from "@/components/Navbar";
// import { Button } from "@/components/ui/button"; // Shadcn not needed, raw buttons used below
import { BACKEND_URL, POLICY_VALIDATOR_ADDRESS, VERCROW_ESCROW_IMPLEMENTATION, MOCK_USDC_ADDRESS } from "@/utils/constants";
import PolicyValidatorABI from "@/utils/contracts/PolicyValidator.json";
import VercrowEscrowABI from "@/utils/contracts/VercrowEscrow.json";
import { Loader2, CheckCircle2, AlertCircle, ArrowRight, BrainCircuit, FileCode, Check } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useDemo } from "@/context/DemoContext";

// Types
type Condition = {
    conditionType: number;
    operator: number;
    value: number;
    required: boolean;
    description?: string;
};

type Intent = {
    amount: number;
    beneficiary: string | null;
    conditions: Condition[];
    deadline: number; // days
    description: string;
    email?: string;
    sellerName?: string;
    notes?: string;
};

const EXAMPLES = [
    "Create 500 USDC escrow for 50 branded hoodies, release on delivery + quality score >= 85%",
    "Pay 1000 USDC for website design, require delivery confirmation within 7 days",
    "Escrow 2500 USDC for cold chain transport, require temp <= 5C and weight >= 1000kg"
];

export default function CreateEscrow() {
    const [step, setStep] = useState(1);
    const [prompt, setPrompt] = useState("");
    const [loading, setLoading] = useState(false);
    const [intent, setIntent] = useState<Intent | null>(null);
    const [validationSteps, setValidationSteps] = useState({ amount: false, conditions: false, beneficiary: false, deadline: false });
    const [nftId, setNftId] = useState<string | null>(null);
    const [escrowAddress, setEscrowAddress] = useState<string | null>(null);
    const [txHash, setTxHash] = useState<string | null>(null);
    const [errorMsg, setErrorMsg] = useState<string | null>(null);
    const [intentHash, setIntentHash] = useState<string | null>(null);
    const { isDemoMode, demoSellerAddress } = useDemo();

    // --- Step 1: Parse Intent ---
    const handleParse = async () => {
        if (!prompt) return;
        setLoading(true);
        try {
            const res = await fetch("/api/parse-escrow", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ text: prompt })
            });
            const data = await res.json();

            // Map backend response to our Intent type if needed
            // Assuming backend returns close to what we need, or we adapt.
            // Based on previous geminiService, it returns { item, quantity, amount, qualityThreshold, deliveryDays }
            // We need to map this to 'Conditions' structure for the new contract.

            const mappedConditions = [];
            if (data.deliveryDays) {
                mappedConditions.push({ conditionType: 0, operator: 0, value: 1, required: true, description: "Delivery Confirmed" });
            }
            if (data.qualityThreshold) {
                mappedConditions.push({ conditionType: 1, operator: 1, value: data.qualityThreshold, required: true, description: `Quality Score >= ${data.qualityThreshold}` });
            }

            // Determine beneficiary
            // If in Demo Mode, use the mock wallet. Else default to test seller or leave empty if we had an input.
            const beneficiary = isDemoMode && demoSellerAddress
                ? demoSellerAddress
                : "0x70997970C51812dc3A010C7d01b50e0d17dc79C8"; // Default test seller (Account #1 in Hardhat)

            setIntent({
                amount: data.amount || 0,
                beneficiary: beneficiary,
                conditions: mappedConditions,
                deadline: data.deliveryDays || 30,
                description: `Escrow for ${data.quantity || 1} ${data.item || "items"}`,
                email: data.email || "",
                sellerName: data.sellerName || "",
                notes: data.notes || ""
            });

            setStep(2);
        } catch (e) {
            console.error(e);
            alert("Failed to parse intent. Please try again.");
        } finally {
            setLoading(false);
        }
    };

    // --- Step 3: Validate & Mint ---
    const handleMint = async () => {
        if (!intent) return;
        setStep(3);

        // 1. Validate Amount
        await new Promise(r => setTimeout(r, 500));
        if (intent.amount < 0 || intent.amount > 1000000000) {
            alert("❌ Policy Validation Failed: Amount must be between 0 and 1,000,000,000 USDC.");
            setStep(2); // Return to review
            return;
        }
        setValidationSteps(p => ({ ...p, amount: true }));

        // 2. Validate Conditions
        await new Promise(r => setTimeout(r, 500));
        if (intent.conditions.length === 0) {
            alert("❌ Policy Validation Failed: At least one condition is required.");
            setStep(2);
            return;
        }
        setValidationSteps(p => ({ ...p, conditions: true }));

        // 3. Validate Beneficiary
        await new Promise(r => setTimeout(r, 500));
        if (!ethers.isAddress(intent.beneficiary)) {
            alert("❌ Policy Validation Failed: Invalid Beneficiary Address.");
            setStep(2);
            return;
        }
        setValidationSteps(p => ({ ...p, beneficiary: true }));

        // 4. Validate Deadline
        await new Promise(r => setTimeout(r, 500));
        if (intent.deadline <= 0) {
            alert("❌ Policy Validation Failed: Deadline must be positive.");
            setStep(2);
            return;
        }
        setValidationSteps(p => ({ ...p, deadline: true }));

        await new Promise(r => setTimeout(r, 800));

        try {
            const provider = new BrowserProvider(window.ethereum);
            const signer = await provider.getSigner();
            const contract = new Contract(POLICY_VALIDATOR_ADDRESS, PolicyValidatorABI.abi, signer);

            // Construct struct for contract
            const contractIntent = {
                creator: await signer.getAddress(),
                beneficiary: intent.beneficiary,
                amount: parseUnits(intent.amount.toString(), 6), // USDC 6 decimals
                conditions: intent.conditions.map(c => ({
                    conditionType: c.conditionType,
                    operator: c.operator,
                    value: c.value,
                    required: c.required
                })),
                deadline: Math.floor(Date.now() / 1000) + (intent.deadline * 86400)
            };

            const tx = await contract.validateAndMintIntent(contractIntent);
            const receipt = await tx.wait();

            // Extract intentHash and tokenId from IntentValidated event
            let extractedHash: string | null = null;
            let extractedTokenId: string | null = null;

            for (const log of receipt.logs) {
                try {
                    const parsed = contract.interface.parseLog({
                        topics: log.topics as string[],
                        data: log.data
                    });
                    if (parsed && parsed.name === "IntentValidated") {
                        extractedHash = parsed.args.intentHash;
                        extractedTokenId = parsed.args.tokenId.toString();
                        break;
                    }
                } catch (e) {
                    // Not our event, continue
                }
            }

            if (extractedHash && extractedTokenId) {
                setIntentHash(extractedHash);
                setNftId(extractedTokenId);
            } else {
                // Fallback
                setNftId("1");
                console.warn("Could not extract intentHash from event");
            }
        } catch (e) {
            console.error(e);
            const msg = (e as any).message || "Transaction failed";
            setErrorMsg(msg.length > 100 ? msg.slice(0, 100) + "..." : msg);
            alert("Minting failed: " + msg);
            setStep(3); // Stay on step 3 but verify state
        }
    };

    // --- Step 4: Deploy Escrow ---
    // Note: Since we don't have a Factory, we will use ethers to deploy the bytecode of VercrowEscrow
    // and call initialize.
    const handleDeploy = async () => {
        if (!intent || !intentHash) {
            alert("Missing intent data or hash. Please restart the flow.");
            return;
        }

        setStep(4);
        try {
            const provider = new BrowserProvider(window.ethereum);
            const signer = await provider.getSigner();
            const creatorAddress = await signer.getAddress();

            // 1. Deploy new VercrowEscrow instance
            const factory = new ethers.ContractFactory(VercrowEscrowABI.abi, VercrowEscrowABI.bytecode, signer);
            const deployed = await factory.deploy();
            await deployed.waitForDeployment();
            const escrowAddr = await deployed.getAddress();

            setTxHash(deployed.deploymentTransaction()?.hash || "");
            setEscrowAddress(escrowAddr);

            // 2. Initialize the escrow contract using Contract interface
            const escrowContract = new Contract(escrowAddr, VercrowEscrowABI.abi, signer);
            const deadlineTimestamp = Math.floor(Date.now() / 1000) + (intent.deadline * 86400);
            const amountWei = parseUnits(intent.amount.toString(), 6);

            const initTx = await escrowContract.initialize(
                creatorAddress,
                intent.beneficiary,
                amountWei,
                intentHash,
                deadlineTimestamp,
                POLICY_VALIDATOR_ADDRESS,
                MOCK_USDC_ADDRESS
            );
            await initTx.wait();

            // 3. Redirect to escrow detail page
            setTimeout(() => {
                window.location.href = `/escrow/${escrowAddr}`;
            }, 2000);

        } catch (e) {
            console.error(e);
            alert("Deployment failed: " + (e as any).message);
            setStep(3); // Go back to allow retry
        }
    };


    return (
        <div className="min-h-screen bg-black text-white">
            <Navbar />
            <div className="pt-24 max-w-4xl mx-auto px-4 pb-20">

                {/* Stepper */}
                <div className="flex justify-between mb-12 relative">
                    <div className="absolute top-1/2 w-full h-1 bg-white/10 -z-10 rounded-full" />
                    {[1, 2, 3, 4].map(s => (
                        <div key={s} className={`w-10 h-10 rounded-full flex items-center justify-center font-bold bg-black border-2 transition-colors ${step >= s ? "border-indigo-500 text-indigo-500" : "border-gray-700 text-gray-700"}`}>
                            {step > s ? <Check className="w-5 h-5" /> : s}
                        </div>
                    ))}
                </div>

                <AnimatePresence mode="wait">
                    {step === 1 && (
                        <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }} key="step1">
                            <h1 className="text-4xl font-bold mb-2">Describe your Escrow</h1>
                            <p className="text-gray-400 mb-8">Concept to Contract in 30 seconds.</p>

                            <textarea
                                value={prompt}
                                onChange={e => setPrompt(e.target.value)}
                                className="w-full h-40 bg-white/5 border border-white/10 rounded-xl p-6 text-xl focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none resize-none mb-4"
                                placeholder="E.g., Create 500 USDC escrow for 50 branded hoodies..."
                            />

                            <div className="flex gap-2 flex-wrap mb-8">
                                {EXAMPLES.map((ex, i) => (
                                    <button key={i} onClick={() => setPrompt(ex)} className="px-3 py-1 text-xs bg-white/5 hover:bg-white/10 rounded-full border border-white/5 transition-colors text-left">
                                        {ex}
                                    </button>
                                ))}
                            </div>

                            <button onClick={handleParse} disabled={loading || !prompt} className="w-full py-4 bg-indigo-600 hover:bg-indigo-700 rounded-xl font-bold text-lg flex items-center justify-center gap-2">
                                {loading ? <Loader2 className="animate-spin" /> : <><BrainCircuit /> Parse Intent</>}
                            </button>
                        </motion.div>
                    )}

                    {step === 2 && intent && (
                        <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }} key="step2">
                            <h1 className="text-3xl font-bold mb-6">Refine & Validate Details</h1>

                            {isDemoMode && (
                                <div className="mb-6 bg-amber-500/10 border border-amber-500/20 p-4 rounded-xl flex items-center gap-3">
                                    <div className="w-10 h-10 rounded-full bg-amber-500/20 flex items-center justify-center text-2xl">🤖</div>
                                    <div>
                                        <p className="font-bold text-amber-500">Demo Mode Active</p>
                                        <p className="text-xs text-amber-200/70">Seller wallet auto-filled. You can edit if needed.</p>
                                    </div>
                                </div>
                            )}

                            <div className="bg-white/5 border border-white/10 rounded-xl p-8 space-y-8 mb-8">
                                {/* Row 1: Amount & Deadline */}
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                    <div>
                                        <h3 className="text-gray-400 text-sm uppercase tracking-wider mb-2">Escrow Amount</h3>
                                        <div className="flex items-end gap-2 border-b border-gray-700 pb-2">
                                            <input
                                                type="number"
                                                value={intent.amount}
                                                onChange={e => setIntent({ ...intent, amount: Number(e.target.value) })}
                                                className="text-4xl font-bold font-mono bg-transparent outline-none w-full text-white placeholder-gray-600"
                                                placeholder="0.00"
                                            />
                                            <span className="text-xl text-gray-500 mb-1">USDC</span>
                                        </div>
                                    </div>
                                    <div>
                                        <h3 className="text-gray-400 text-sm uppercase tracking-wider mb-2">Deadline (Days)</h3>
                                        <div className="flex items-end gap-2 border-b border-gray-700 pb-2">
                                            <input
                                                type="number"
                                                value={intent.deadline}
                                                onChange={e => setIntent({ ...intent, deadline: Number(e.target.value) })}
                                                className="text-4xl font-bold font-mono bg-transparent outline-none w-full text-white placeholder-gray-600"
                                            />
                                            <span className="text-xl text-gray-500 mb-1">Days</span>
                                        </div>
                                    </div>
                                </div>

                                {/* Row 2: Beneficiary & Seller Details */}
                                <div>
                                    <h3 className="text-gray-400 text-sm uppercase tracking-wider mb-2">Seller Wallet Address</h3>
                                    <input
                                        type="text"
                                        value={intent.beneficiary || ""}
                                        onChange={e => setIntent({ ...intent, beneficiary: e.target.value })}
                                        className="w-full bg-black/30 border border-gray-700 rounded-lg p-3 font-mono text-sm text-gray-300 focus:border-indigo-500 outline-none mb-1"
                                        placeholder="0x..."
                                    />
                                    {isDemoMode && <p className="text-xs text-amber-500 mb-4">Simulated Agent Wallet (Demo)</p>}
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                    <div>
                                        <h3 className="text-gray-400 text-sm uppercase tracking-wider mb-2">Seller/Counterparty Name</h3>
                                        <input
                                            type="text"
                                            value={intent.sellerName || ""}
                                            onChange={e => setIntent({ ...intent, sellerName: e.target.value })}
                                            className="w-full bg-black/30 border border-gray-700 rounded-lg p-3 text-white focus:border-indigo-500 outline-none"
                                            placeholder="e.g. Acme Corp Logistics"
                                        />
                                    </div>
                                    <div>
                                        <h3 className="text-gray-400 text-sm uppercase tracking-wider mb-2">Notification Email</h3>
                                        <input
                                            type="email"
                                            value={intent.email || ""}
                                            onChange={e => setIntent({ ...intent, email: e.target.value })}
                                            className="w-full bg-black/30 border border-gray-700 rounded-lg p-3 text-white focus:border-indigo-500 outline-none"
                                            placeholder="alerts@example.com"
                                        />
                                    </div>
                                </div>

                                <div>
                                    <h3 className="text-gray-400 text-sm uppercase tracking-wider mb-2">Notes / Memo (Encrypted)</h3>
                                    <textarea
                                        value={intent.notes || ""}
                                        onChange={e => setIntent({ ...intent, notes: e.target.value })}
                                        className="w-full bg-black/30 border border-gray-700 rounded-lg p-3 text-gray-300 focus:border-indigo-500 outline-none resize-none h-20"
                                        placeholder="Private details regarding this transaction..."
                                    />
                                </div>

                                {/* Row 3: Conditions */}
                                <div className="border-t border-white/10 pt-6">
                                    <div className="flex justify-between items-center mb-4">
                                        <h3 className="text-gray-400 text-sm uppercase tracking-wider">Conditions Policy</h3>
                                        <button
                                            onClick={() => setIntent({
                                                ...intent,
                                                conditions: [...intent.conditions, { conditionType: 0, operator: 0, value: 0, required: true, description: "New Condition" }]
                                            })}
                                            className="text-xs bg-indigo-500/20 text-indigo-400 px-2 py-1 rounded hover:bg-indigo-500/30"
                                        >
                                            + Add Condition
                                        </button>
                                    </div>
                                    <div className="space-y-3">
                                        {intent.conditions.map((c, i) => (
                                            <div key={i} className="flex items-center gap-3 bg-black/30 p-3 rounded-lg border border-white/5 group">
                                                <div className="w-8 h-8 rounded-full bg-indigo-500/20 flex items-center justify-center text-indigo-400 font-bold text-xs">{i + 1}</div>
                                                <input
                                                    type="text"
                                                    value={c.description}
                                                    onChange={(e) => {
                                                        const newConds = [...intent.conditions];
                                                        newConds[i].description = e.target.value;
                                                        setIntent({ ...intent, conditions: newConds });
                                                    }}
                                                    className="flex-1 bg-transparent border-none outline-none font-mono text-sm"
                                                />
                                                <button
                                                    onClick={() => {
                                                        const newConds = intent.conditions.filter((_, idx) => idx !== i);
                                                        setIntent({ ...intent, conditions: newConds });
                                                    }}
                                                    className="text-gray-600 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity"
                                                >
                                                    Remove
                                                </button>
                                            </div>
                                        ))}
                                        {intent.conditions.length === 0 && (
                                            <p className="text-gray-500 italic text-sm text-center py-4">No conditions set. Add one above.</p>
                                        )}
                                    </div>
                                </div>
                            </div>

                            <div className="flex gap-4">
                                <button onClick={() => setStep(1)} className="flex-1 py-4 bg-transparent border border-white/20 hover:bg-white/5 rounded-xl font-bold">Back to NLP</button>
                                <button onClick={handleMint} className="flex-[2] py-4 bg-indigo-600 hover:bg-indigo-700 rounded-xl font-bold text-lg flex items-center justify-center gap-2">
                                    Approve & Validate <ArrowRight />
                                </button>
                            </div>
                        </motion.div>
                    )}

                    {step === 3 && (
                        <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }} key="step3" className="text-center py-12">
                            <h1 className="text-3xl font-bold mb-12">Validating Policy Logic</h1>

                            <div className="space-y-6 max-w-sm mx-auto mb-12 text-left">
                                <ValidationItem label="Amount within limits (0-1B)" checked={validationSteps.amount} />
                                <ValidationItem label="Conditions authorized" checked={validationSteps.conditions} />
                                <ValidationItem label="Beneficiary check" checked={validationSteps.beneficiary} />
                                <ValidationItem label="Deadline in future" checked={validationSteps.deadline} />
                            </div>

                            {validationSteps.deadline && !nftId && !txHash && (
                                <div className="flex flex-col items-center gap-4">
                                    <Loader2 className="w-12 h-12 text-indigo-500 animate-spin" />
                                    <p className="text-indigo-300 animate-pulse">Minting Intent NFT...</p>
                                    <p className="text-gray-500 text-sm max-w-xs">Please confirm the transaction in your wallet.</p>
                                </div>
                            )}

                            {/* Error Display */}
                            {errorMsg && (
                                <div className="text-red-400 mt-8 text-sm font-mono max-w-xl mx-auto bg-red-500/10 p-4 rounded-xl border border-red-500/20 break-words">
                                    <div className="flex items-center justify-center gap-2 mb-2 font-bold uppercase"><AlertCircle className="w-4 h-4" /> Minting Error</div>
                                    {errorMsg}
                                    <div className="mt-4 text-gray-400 text-xs text-left">
                                        <p className="font-bold text-white mb-1">Common Fix:</p>
                                        <ul className="list-disc pl-4 space-y-1">
                                            <li>Open Metamask Extension</li>
                                            <li>Go to <b>Settings &gt; Advanced &gt; Clear Activity Tab Data</b></li>
                                            <li>This resets the &quot;Nonce&quot; which gets out of sync on Localhost.</li>
                                        </ul>
                                    </div>
                                    <div className="flex gap-3 mt-4">
                                        <button
                                            onClick={() => { setErrorMsg(null); setStep(2); }}
                                            className="flex-1 py-2 bg-white/10 hover:bg-white/20 rounded-lg font-bold transition"
                                        >
                                            ← Back to Form
                                        </button>
                                        <button
                                            onClick={() => { setErrorMsg(null); handleMint(); }}
                                            className="flex-1 py-2 bg-indigo-600 hover:bg-indigo-700 rounded-lg font-bold transition"
                                        >
                                            Try Again
                                        </button>
                                    </div>
                                </div>
                            )}

                            {nftId && (
                                <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="bg-gradient-to-br from-indigo-900/50 to-purple-900/50 p-8 rounded-2xl border border-indigo-500/50 mb-8">
                                    <FileCode className="w-16 h-16 mx-auto mb-4 text-indigo-400" />
                                    <h3 className="text-2xl font-bold text-white mb-2">Intent Validated</h3>
                                    <p className="font-mono text-indigo-300 mb-6">Token ID: #{nftId}</p>
                                    <button onClick={handleDeploy} className="w-full py-3 bg-white text-black font-bold rounded-xl hover:bg-gray-200 transition-colors">
                                        Deploy Escrow Contract
                                    </button>
                                </motion.div>
                            )}
                        </motion.div>
                    )}

                    {step === 4 && (
                        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} key="step4" className="text-center py-20">
                            <div className="w-24 h-24 rounded-full border-4 border-t-indigo-500 border-white/10 animate-spin mx-auto mb-8" />
                            <h2 className="text-3xl font-bold mb-4">Creating Your Digital Vault...</h2>
                            <p className="text-gray-400 max-w-lg mx-auto mb-8 text-lg">
                                We are deploying a <span className="text-white font-bold">Smart Contract</span> on the blockchain.
                            </p>
                            <div className="bg-indigo-500/10 border border-indigo-500/20 p-6 rounded-xl max-w-lg mx-auto text-left space-y-3">
                                <h3 className="text-indigo-400 font-bold uppercase text-xs tracking-wider">What is happening?</h3>
                                <p className="text-sm text-gray-300">
                                    Unlike a generic database entry, we are creating a <b>unique, standalone program</b> that lives on the blockchain forever.
                                </p>
                                <ul className="list-disc pl-4 text-xs text-gray-400 space-y-1">
                                    <li><b>Tamper-Proof:</b> Once deployed, even <i>we</i> cannot change the rules.</li>
                                    <li><b>Trustless:</b> The code controls the money, not a middleman.</li>
                                    <li><b>Global:</b> Accessible by anyone, anywhere, instantly.</li>
                                </ul>
                            </div>

                            {txHash && (
                                <div className="mt-8 bg-white/5 p-4 rounded-lg font-mono text-xs text-center max-w-lg mx-auto text-green-400 border border-green-500/20 animate-pulse">
                                    TX HASH: {txHash}
                                </div>
                            )}
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>
        </div>
    );
}

function ValidationItem({ label, checked }: { label: string, checked: boolean }) {
    return (
        <div className="flex items-center gap-4">
            <div className={`w-6 h-6 rounded-full flex items-center justify-center border transition-all ${checked ? "bg-green-500 border-green-500" : "border-gray-600"}`}>
                {checked && <Check className="w-4 h-4 text-black" />}
            </div>
            <span className={`text-lg transition-colors ${checked ? "text-white" : "text-gray-500"}`}>{label}</span>
        </div>
    );
}
