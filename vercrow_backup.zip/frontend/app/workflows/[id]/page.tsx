"use client";

import { useEffect, useRef, useState } from "react";
import * as d3 from "d3";
import Navbar from "@/components/Navbar";
import { useParams } from "next/navigation";
import { Loader2, Activity, CheckCircle, XCircle, Play, Server } from "lucide-react";

// Types
type Node = {
    id: string;
    label: string;
    group: number;
    status: "idle" | "active" | "completed" | "failed";
    x?: number;
    y?: number;
};

type Link = {
    source: string;
    target: string;
    value: number;
    status: "pending" | "active" | "completed";
};

export default function WorkflowPage() {
    const params = useParams();
    const id = params.id as string;
    const svgRef = useRef<SVGSVGElement>(null);
    const [events, setEvents] = useState<any[]>([]);

    // Initial Graph Data
    const [nodes, setNodes] = useState<Node[]>([
        { id: "User", label: "User Intent", group: 1, status: "completed" },
        { id: "Parser", label: "Intent Parser MCP", group: 2, status: "completed" },
        { id: "Policy", label: "Policy Validator", group: 2, status: "completed" },
        { id: "Contract", label: "Smart Contract", group: 3, status: "active" },
        { id: "Delivery", label: "Delivery MCP", group: 4, status: "idle" },
        { id: "Quality", label: "Quality MCP", group: 4, status: "idle" },
        { id: "Release", label: "Fund Release", group: 5, status: "idle" }
    ]);

    const [links, setLinks] = useState<Link[]>([
        { source: "User", target: "Parser", value: 1, status: "completed" },
        { source: "Parser", target: "Policy", value: 1, status: "completed" },
        { source: "Policy", target: "Contract", value: 1, status: "completed" },
        { source: "Contract", target: "Delivery", value: 1, status: "active" },
        { source: "Contract", target: "Quality", value: 1, status: "active" },
        { source: "Delivery", target: "Release", value: 1, status: "pending" },
        { source: "Quality", target: "Release", value: 1, status: "pending" }
    ]);

    // Mock Real-time Updates
    useEffect(() => {
        const timer1 = setTimeout(() => {
            addEvent("MCP Activated", "Delivery MCP started monitoring shipment.");
            updateNodeStatus("Delivery", "active");
        }, 2000);

        const timer2 = setTimeout(() => {
            addEvent("Proof Generated", "Delivery Confirmed by Oracle.");
            updateNodeStatus("Delivery", "completed");
            updateLinkStatus("Delivery", "Release", "active");
        }, 5000);

        const timer3 = setTimeout(() => {
            addEvent("MCP Activated", "Quality Inspection MCP started.");
            updateNodeStatus("Quality", "active");
        }, 6000);

        const timer4 = setTimeout(() => {
            addEvent("Proof Generated", "Quality Score: 98/100 verified.");
            updateNodeStatus("Quality", "completed");
            updateLinkStatus("Quality", "Release", "active");
        }, 9000);

        const timer5 = setTimeout(() => {
            addEvent("Contract Action", "All conditions met. Releasing funds.");
            updateNodeStatus("Release", "completed");
        }, 11000);

        return () => {
            clearTimeout(timer1); clearTimeout(timer2); clearTimeout(timer3); clearTimeout(timer4); clearTimeout(timer5);
        };
    }, []);

    const addEvent = (type: string, msg: string) => {
        setEvents(prev => [...prev, { type, msg, time: new Date().toLocaleTimeString() }]);
    };

    const updateNodeStatus = (id: string, status: any) => {
        setNodes(prev => prev.map(n => n.id === id ? { ...n, status } : n));
    };

    const updateLinkStatus = (source: string, target: string, status: any) => {
        setLinks(prev => prev.map(l => (l.source === source && l.target === target) ? { ...l, status } : l));
    };

    // D3 Rendering Logic
    useEffect(() => {
        if (!svgRef.current) return;

        const width = 800;
        const height = 400;

        // Clear previous
        d3.select(svgRef.current).selectAll("*").remove();

        const svg = d3.select(svgRef.current)
            .attr("viewBox", [0, 0, width, height])
            .attr("style", "max-width: 100%; height: auto;");

        // Simulation
        const simulation = d3.forceSimulation(nodes as d3.SimulationNodeDatum[])
            .force("link", d3.forceLink(links).id((d: any) => d.id).distance(100))
            .force("charge", d3.forceManyBody().strength(-500))
            .force("center", d3.forceCenter(width / 2, height / 2));

        // Links
        const link = svg.append("g")
            .selectAll("line")
            .data(links)
            .join("line")
            .attr("stroke", d => {
                if (d.status === "completed") return "#10B981"; // Green
                if (d.status === "active") return "#6366F1"; // Blue
                return "#374151"; // Gray
            })
            .attr("stroke-width", d => d.status === "active" ? 3 : 2)
            .attr("stroke-dasharray", d => d.status === "pending" ? "5,5" : "none");

        // Nodes
        const node = svg.append("g")
            .selectAll("g")
            .data(nodes)
            .join("g")
            .call(d3.drag<any, any>()
                .on("start", dragstarted)
                .on("drag", dragged)
                .on("end", dragended));

        // Node Circles
        node.append("circle")
            .attr("r", 20)
            .attr("fill", d => {
                if (d.status === "completed") return "#10B981";
                if (d.status === "active") return "#6366F1";
                if (d.status === "failed") return "#EF4444";
                return "#1F2937";
            })
            .attr("stroke", "#fff")
            .attr("stroke-width", 2);

        // Pulse effect for active
        node.filter(d => d.status === "active")
            .append("circle")
            .attr("r", 30)
            .attr("fill", "none")
            .attr("stroke", "#6366F1")
            .attr("stroke-opacity", 0.5)
            .append("animate")
            .attr("attributeName", "r")
            .attr("from", 20)
            .attr("to", 40)
            .attr("dur", "1.5s")
            .attr("repeatCount", "indefinite");

        node.filter(d => d.status === "active")
            .select("animate")
            .clone(true)
            .attr("attributeName", "opacity")
            .attr("from", 1)
            .attr("to", 0);

        // Labels
        node.append("text")
            .text(d => d.label)
            .attr("x", 25)
            .attr("y", 5)
            .attr("fill", "white")
            .attr("font-size", "12px")
            .style("pointer-events", "none")
            .style("text-shadow", "0 1px 4px black");

        simulation.on("tick", () => {
            link
                .attr("x1", (d: any) => d.source.x)
                .attr("y1", (d: any) => d.source.y)
                .attr("x2", (d: any) => d.target.x)
                .attr("y2", (d: any) => d.target.y);

            node
                .attr("transform", (d: any) => `translate(${d.x},${d.y})`);
        });

        function dragstarted(event: any) {
            if (!event.active) simulation.alphaTarget(0.3).restart();
            event.subject.fx = event.subject.x;
            event.subject.fy = event.subject.y;
        }

        function dragged(event: any) {
            event.subject.fx = event.x;
            event.subject.fy = event.y;
        }

        function dragended(event: any) {
            if (!event.active) simulation.alphaTarget(0);
            event.subject.fx = null;
            event.subject.fy = null;
        }

        return () => {
            simulation.stop();
        };
    }, [nodes, links]); // Re-render when data changes

    return (
        <div className="min-h-screen bg-black text-white">
            <Navbar />
            <div className="pt-24 max-w-7xl mx-auto px-4 pb-20">
                <div className="flex justify-between items-center mb-8">
                    <div>
                        <h1 className="text-3xl font-bold">Workflow Visualization</h1>
                        <p className="text-gray-400">Real-time MCP Agent Network</p>
                    </div>
                    <div className="flex gap-2">
                        <span className="px-3 py-1 bg-green-500/10 text-green-400 rounded-full text-xs font-bold border border-green-500/20 flex items-center gap-2">
                            <Activity className="w-3 h-3" /> Live Channel
                        </span>
                    </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    {/* Main Graph */}
                    <div className="lg:col-span-2 bg-white/5 border border-white/10 rounded-xl p-4 min-h-[500px] flex items-center justify-center relative overflow-hidden">
                        <svg ref={svgRef} className="w-full h-full" />
                        <div className="absolute bottom-4 left-4 text-xs text-gray-500">
                            * Nodes draggable manually for inspection
                        </div>
                    </div>

                    {/* Sidebar Events */}
                    <div className="space-y-6">
                        {/* Server Status Grid */}
                        <div className="grid grid-cols-2 gap-4">
                            {["Parser", "Policy", "Delivery", "Quality"].map(m => {
                                const node = nodes.find(n => n.id.includes(m.split(" ")[0]));
                                const active = node?.status === "active";
                                const done = node?.status === "completed";

                                return (
                                    <div key={m} className={`p-3 rounded-lg border flex flex-col items-center justify-center text-center transition-colors ${active ? "bg-indigo-900/30 border-indigo-500" : done ? "bg-green-900/10 border-green-500/30" : "bg-white/5 border-white/10"}`}>
                                        <Server className={`w-5 h-5 mb-2 ${active ? "text-indigo-400 animate-pulse" : done ? "text-green-500" : "text-gray-500"}`} />
                                        <span className="text-xs font-bold text-gray-300">{m}</span>
                                        <span className="text-[10px] text-gray-500 mt-1 uppercase">{node?.status}</span>
                                    </div>
                                );
                            })}
                        </div>

                        {/* Event Log */}
                        <div className="bg-black/50 border border-white/10 rounded-xl p-0 overflow-hidden flex flex-col h-[300px]">
                            <div className="p-4 border-b border-white/10 bg-white/5">
                                <h3 className="font-bold text-sm">Real-time Event Log</h3>
                            </div>
                            <div className="flex-1 overflow-y-auto p-4 space-y-4 font-mono text-sm">
                                {events.length === 0 && <p className="text-gray-600 italic">Waiting for agents...</p>}
                                {events.map((e, i) => (
                                    <div key={i} className="flex gap-3 animate-in slide-in-from-right fade-in duration-300">
                                        <div className="mt-1 w-2 h-2 rounded-full bg-blue-500 shrink-0" />
                                        <div>
                                            <p className="text-gray-500 text-[10px]">{e.time}</p>
                                            <p className="font-bold text-indigo-300">{e.type}</p>
                                            <p className="text-gray-400">{e.msg}</p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
