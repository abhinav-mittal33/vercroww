"use client";

import { useEffect, useState } from "react";
import Navbar from "@/components/Navbar";
import EscrowCard from "@/components/EscrowCard";
import { BrowserProvider, Contract, formatEther } from "ethers";
import VercrowEscrowABI from "@/utils/contracts/VercrowEscrow.json";
import MockERC20ABI from "@/utils/contracts/MockUSDC.json";
import { VERCROW_ESCROW_ADDRESS, MOCK_USDC_ADDRESS, BACKEND_URL } from "@/utils/constants";
import { Loader2, Coins } from "lucide-react";

export default function Dashboard() {
    const [escrows, setEscrows] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [userAddress, setUserAddress] = useState("");
    const [hasMetaMask, setHasMetaMask] = useState(true);
    const [balance, setBalance] = useState("0");
    const [faucetLoading, setFaucetLoading] = useState(false);
    const [isWrongNetwork, setIsWrongNetwork] = useState(false);

    const fetchEscrows = async () => {
        if (!window.ethereum) {
            setHasMetaMask(false);
            setLoading(false);
            return;
        }

        try {
            const provider = new BrowserProvider(window.ethereum);
            const signer = await provider.getSigner();
            const address = await signer.getAddress();
            setUserAddress(address);

            // Check Balance
            const bal = await provider.getBalance(address);
            setBalance(formatEther(bal));

            if (!VERCROW_ESCROW_ADDRESS) return;

            const contract = new Contract(VERCROW_ESCROW_ADDRESS, VercrowEscrowABI.abi, signer);
            const count = await contract.nextEscrowId();

            const loadedEscrows = [];
            // Loop backwards for newest first
            for (let i = Number(count) - 1; i >= 0; i--) {
                const data = await contract.escrows(i);
                loadedEscrows.push(data);
            }
            setEscrows(loadedEscrows);
        } catch (error) {
            console.error("Fetch error", error);
        } finally {
            setLoading(false);
        }
    };

    const checkNetwork = async () => {
        if (!window.ethereum) return;
        const chainId = await window.ethereum.request({ method: 'eth_chainId' });
        // 31337 in hex is 0x7a69
        if (chainId !== '0x7a69') {
            setIsWrongNetwork(true);
        } else {
            setIsWrongNetwork(false);
        }
    };

    const switchNetwork = async () => {
        if (!window.ethereum) return;
        try {
            await window.ethereum.request({
                method: 'wallet_switchEthereumChain',
                params: [{ chainId: '0x7a69' }],
            });
            window.location.reload();
        } catch (switchError: any) {
            // This error code indicates that the chain has not been added to MetaMask.
            if (switchError.code === 4902) {
                try {
                    await window.ethereum.request({
                        method: 'wallet_addEthereumChain',
                        params: [
                            {
                                chainId: '0x7a69',
                                chainName: 'Localhost 8545',
                                nativeCurrency: {
                                    name: 'ETH',
                                    symbol: 'ETH',
                                    decimals: 18,
                                },
                                rpcUrls: ['http://127.0.0.1:8545'],
                            },
                        ],
                    });
                    window.location.reload();
                } catch (addError) {
                    console.error(addError);
                }
            }
        }
    };

    const handleRequestFunds = async () => {
        if (!userAddress) return;
        setFaucetLoading(true);
        try {
            const res = await fetch(`${BACKEND_URL}/api/request-funds`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ address: userAddress })
            });
            const data = await res.json();
            if (data.success) {
                alert("10 ETH Sent! Balance will update shortly.");
                window.location.reload();
            } else {
                alert("Faucet failed: " + (data.error || "Unknown error"));
            }
        } catch (e) {
            console.error(e);
            alert("Faucet failed to connect.");
        } finally {
            setFaucetLoading(false);
        }
    };

    useEffect(() => {
        if (window.ethereum) {
            setHasMetaMask(true);
            checkNetwork();

            window.ethereum.request({ method: 'eth_requestAccounts' })
                .then(() => fetchEscrows())
                .catch((err: any) => {
                    console.error(err);
                    setLoading(false);
                });

            // Listen for account changes
            window.ethereum.on('accountsChanged', () => window.location.reload());
            window.ethereum.on('chainChanged', () => window.location.reload());
        } else {
            setHasMetaMask(false);
            setLoading(false);
        }
    }, []);

    const handleDeposit = async (id: any) => {
        try {
            const provider = new BrowserProvider(window.ethereum);
            const signer = await provider.getSigner();
            const contract = new Contract(VERCROW_ESCROW_ADDRESS, VercrowEscrowABI.abi, signer);
            const usdc = new Contract(MOCK_USDC_ADDRESS, MockERC20ABI.abi, signer);

            // Check allowance
            const escrowStruct = await contract.escrows(id);
            const amount = escrowStruct.amount;

            const txApprove = await usdc.approve(VERCROW_ESCROW_ADDRESS, amount);
            await txApprove.wait();

            const tx = await contract.deposit(id);
            await tx.wait();

            alert("Deposit Successful!");
            fetchEscrows();
        } catch (e) {
            console.error(e);
            alert("Deposit Failed");
        }
    };

    const handleApprove = async (id: any) => {
        try {
            const provider = new BrowserProvider(window.ethereum);
            const signer = await provider.getSigner();
            const contract = new Contract(VERCROW_ESCROW_ADDRESS, VercrowEscrowABI.abi, signer);

            const tx = await contract.approveEscrow(id);
            await tx.wait();

            alert("Approved!");
            fetchEscrows();
        } catch (e) {
            console.error(e);
            alert("Approval Failed");
        }
    };

    if (isWrongNetwork) {
        return (
            <div className="min-h-screen bg-black text-white">
                <Navbar />
                <div className="pt-32 max-w-7xl mx-auto px-4 text-center">
                    <h1 className="text-3xl font-bold mb-4 text-amber-500">Wrong Network Detected</h1>
                    <p className="text-gray-400 mb-8">You are connected to the wrong blockchain. Please switch to Localhost 8545.</p>
                    <button
                        onClick={switchNetwork}
                        className="bg-amber-600 hover:bg-amber-700 text-white px-6 py-3 rounded-xl font-bold transition flex items-center gap-2 mx-auto"
                    >
                        Switch to Localhost 8545
                    </button>
                    <p className="text-xs text-gray-600 mt-4">(Chain ID: 31337)</p>
                </div>
            </div>
        );
    }

    if (!hasMetaMask) {
        return (
            <div className="min-h-screen bg-black text-white">
                <Navbar />
                <div className="pt-32 max-w-7xl mx-auto px-4 text-center">
                    <h1 className="text-3xl font-bold mb-4 text-red-500">Wallet Not Detected</h1>
                    <p className="text-gray-400 mb-8">Please install MetaMask to use the Vercrow Dashboard.</p>
                    <a
                        href="https://metamask.io/download/"
                        target="_blank"
                        rel="noreferrer"
                        className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-xl font-bold transition"
                    >
                        Install MetaMask
                    </a>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-black text-white">
            <Navbar />
            <div className="pt-24 max-w-7xl mx-auto px-4 pb-20">
                <div className="flex flex-col md:flex-row justify-between items-center mb-8 gap-4">
                    <h1 className="text-3xl font-bold">Escrow Dashboard</h1>
                    <div className="flex items-center gap-4">
                        {Number(balance) < 0.1 && (
                            <button
                                onClick={handleRequestFunds}
                                disabled={faucetLoading}
                                className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-black font-bold px-4 py-2 rounded-xl flex items-center gap-2 transition disabled:opacity-50"
                            >
                                {faucetLoading ? <Loader2 className="animate-spin w-4 h-4" /> : <Coins className="w-4 h-4" />}
                                Get Test ETH
                            </button>
                        )}
                        {userAddress && (
                            <div className="bg-white/10 px-4 py-2 rounded-lg text-sm font-mono text-indigo-300">
                                {Number(balance).toFixed(2)} ETH | {userAddress.slice(0, 6)}...{userAddress.slice(-4)}
                            </div>
                        )}
                    </div>
                </div>

                {loading ? (
                    <div className="flex justify-center py-20">
                        <Loader2 className="animate-spin w-10 h-10 text-indigo-500" />
                    </div>
                ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {escrows.length === 0 ? (
                            <div className="col-span-full text-center py-20">
                                <p className="text-gray-500 mb-4">No escrows found.</p>
                                <button
                                    onClick={fetchEscrows}
                                    className="text-indigo-400 hover:text-indigo-300 underline"
                                >
                                    Refresh / Connect Wallet
                                </button>
                            </div>
                        ) : (
                            escrows.map((escrow) => (
                                <EscrowCard
                                    key={escrow.id.toString()}
                                    escrow={escrow}
                                    userAddress={userAddress}
                                    onDeposit={handleDeposit}
                                    onApprove={handleApprove}
                                    onRefund={() => { }}
                                />
                            ))
                        )}
                    </div>
                )}
            </div>
        </div>
    );
}
