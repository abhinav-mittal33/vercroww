"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation"; // Correct import for App Router
import Navbar from "@/components/Navbar";
import { BrowserProvider, Contract } from "ethers";
import VercrowEscrowABI from "@/utils/contracts/VercrowEscrow.json";
import { VERCROW_ESCROW_ADDRESS } from "@/utils/constants";
import { Loader2, CheckCircle } from "lucide-react";

export default function ApprovePage() {
    // Correct way to unwrap params in Next.js 15+ (if using 'use' hook) or standard useParams
    // Next.js 15 useParams returns a promise in some contexts, but standard client hook works.
    // However, creating a promise wrapper is safer for future proofing if using params prop.
    // simpler: use standard useParams() from 'next/navigation'
    const params = useParams();
    const id = params.id;
    const router = useRouter();

    const [escrow, setEscrow] = useState<any>(null);
    const [loading, setLoading] = useState(true);
    const [approving, setApproving] = useState(false);

    useEffect(() => {
        if (!id || !window.ethereum) return;

        // Fetch details
        const fetchDetails = async () => {
            try {
                const provider = new BrowserProvider(window.ethereum);
                const contract = new Contract(VERCROW_ESCROW_ADDRESS, VercrowEscrowABI.abi, provider);
                const data = await contract.escrows(id);
                setEscrow(data);
            } catch (e: any) {
                console.error(e);
            } finally {
                setLoading(false);
            }
        };

        fetchDetails();
    }, [id]);

    const handleApprove = async () => {
        if (!window.ethereum) return;
        setApproving(true);
        try {
            const provider = new BrowserProvider(window.ethereum);
            const signer = await provider.getSigner();
            const contract = new Contract(VERCROW_ESCROW_ADDRESS, VercrowEscrowABI.abi, signer);

            const tx = await contract.approveEscrow(id);
            await tx.wait();

            alert("Escrow Approved Successfully!");
            router.push("/dashboard");
        } catch (e: any) {
            console.error(e);
            alert("Approval Failed: " + e.message);
        } finally {
            setApproving(false);
        }
    };

    if (!id) return null;

    return (
        <div className="min-h-screen bg-black text-white">
            <Navbar />
            <div className="pt-32 max-w-xl mx-auto px-4 text-center">
                <h1 className="text-3xl font-bold mb-8">Approve Escrow #{id}</h1>

                {loading ? (
                    <div className="flex justify-center"><Loader2 className="animate-spin" /></div>
                ) : escrow ? (
                    <div className="glass p-8 rounded-2xl border border-white/10 text-left">
                        <div className="mb-6 space-y-4">
                            <div>
                                <p className="text-gray-400 text-xs uppercase">Item</p>
                                <p className="text-xl font-bold">{escrow.item}</p>
                            </div>
                            <div>
                                <p className="text-gray-400 text-xs uppercase">Quantity</p>
                                <p className="text-lg">{escrow.quantity.toString()}</p>
                            </div>
                            <div>
                                <p className="text-gray-400 text-xs uppercase">Amount</p>
                                <p className="text-lg font-mono text-green-400">{(Number(escrow.amount) / 1e6).toLocaleString()} USDC</p>
                            </div>
                        </div>

                        {Number(escrow.status) === 0 ? (
                            <button
                                onClick={handleApprove}
                                disabled={approving}
                                className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-4 rounded-xl transition-all flex items-center justify-center gap-2"
                            >
                                {approving ? <Loader2 className="animate-spin" /> : <CheckCircle />}
                                Sign & Approve
                            </button>
                        ) : (
                            <div className="bg-white/10 p-4 rounded-xl text-center">
                                <p>This escrow is already approved or processed.</p>
                                <button onClick={() => router.push("/dashboard")} className="text-indigo-400 mt-2 text-sm underline">Go to Dashboard</button>
                            </div>
                        )}
                    </div>
                ) : (
                    <p className="text-red-400">Escrow not found on chain.</p>
                )}
            </div>
        </div>
    );
}
