"use client";

import { useEffect, useState } from "react";
import { ethers, BrowserProvider, Contract, formatUnits, parseUnits } from "ethers";
import Navbar from "@/components/Navbar";
import { useParams } from "next/navigation";
import VercrowEscrowABI from "@/utils/contracts/VercrowEscrow.json";
import PolicyValidatorABI from "@/utils/contracts/PolicyValidator.json";
import MockERC20ABI from "@/utils/contracts/MockUSDC.json";
import { MOCK_USDC_ADDRESS, POLICY_VALIDATOR_ADDRESS } from "@/utils/constants";
import { Loader2, CheckCircle2, Clock, AlertTriangle, ShieldCheck, Box, FileText, ArrowRight, Wallet, Coins, UploadCloud } from "lucide-react";
import { motion } from "framer-motion";

// Helper for human readable state
const STATES = ["PENDING", "LOCKED", "VERIFYING", "RELEASED", "DISPUTED", "REFUNDED"];
const COLORS = ["bg-gray-500", "bg-blue-500", "bg-yellow-500", "bg-green-500", "bg-red-500", "bg-orange-500"];

export default function EscrowDetail() {
    const params = useParams();
    const address = params.id as string; // 'id' in the route [id] is the address here (from deployment redirect)

    const [escrow, setEscrow] = useState<any>(null);
    const [conditions, setConditions] = useState<any[]>([]);
    const [proofs, setProofs] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [actionLoading, setActionLoading] = useState(false);
    const [userAddress, setUserAddress] = useState("");
    const [demoMode, setDemoMode] = useState(false);

    // --- Fetch Data ---
    const fetchData = async () => {
        if (!address || !window.ethereum) return;
        try {
            const provider = new BrowserProvider(window.ethereum);
            const signer = await provider.getSigner();
            setUserAddress(await signer.getAddress());

            // 1. Get Escrow Contract
            const contract = new Contract(address, VercrowEscrowABI.abi, signer);

            // 2. basic state
            const stateIdx = Number(await contract.state());
            const amount = await contract.amount();
            const beneficiary = await contract.beneficiary();
            const creator = await contract.creator();
            const intentHash = await contract.intentHash();
            const disputeFlag = await contract.disputeFlag();
            const totalConditions = await contract.totalConditions();
            const proofsSubmitted = await contract.proofsSubmitted();

            // 3. Get conditions via PolicyValidator
            const policyContract = new Contract(POLICY_VALIDATOR_ADDRESS, PolicyValidatorABI.abi, signer);
            // Intent struct is returned as tuple. 
            // struct Intent { creator, beneficiary, amount, conditions[], deadline }
            // conditions is array of Condition { type, operator, value, required }
            const intentData = await policyContract.getIntent(intentHash);

            // Parse conditions
            // intentData[3] is the conditions array
            const rawConditions = intentData[3];
            const parsedConditions = rawConditions.map((c: any, i: number) => ({
                index: i,
                type: Number(c[0]),
                operator: Number(c[1]),
                value: Number(c[2]),
                required: c[3]
            }));

            // 4. Check proofs for each condition
            const loadedProofs = [];
            for (let i = 0; i < Number(totalConditions); i++) {
                const p = await contract.submittedProofs(i);
                if (p.verified) {
                    loadedProofs.push({
                        index: i,
                        source: p.source,
                        value: Number(p.value),
                        timestamp: Number(p.timestamp)
                    });
                }
            }

            setEscrow({
                address,
                state: STATES[stateIdx],
                stateIdx,
                amount: formatUnits(amount, 6), // USDC
                beneficiary,
                creator,
                disputeFlag,
                proofsCount: Number(proofsSubmitted)
            });
            setConditions(parsedConditions);
            setProofs(loadedProofs);

        } catch (e) {
            console.error(e);
            alert("Failed to load escrow data. Ensure you are on the correct network.");
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchData();
        setupEventListeners();
    }, [address]);

    const setupEventListeners = async () => {
        if (!address || !window.ethereum) return;

        try {
            const provider = new BrowserProvider(window.ethereum);
            const contract = new Contract(address, VercrowEscrowABI.abi, provider);

            // Listen for events
            contract.on("EscrowFunded", () => {
                console.log("EscrowFunded event detected");
                fetchData();
            });

            contract.on("ProofSubmitted", () => {
                console.log("ProofSubmitted event detected");
                fetchData();
            });

            contract.on("FundsReleased", () => {
                console.log("FundsReleased event detected");
                fetchData();
            });

            // Cleanup
            return () => {
                contract.removeAllListeners();
            };
        } catch (e) {
            console.error("Event listener setup failed", e);
        }
    };


    // --- Actions ---

    const handleFaucet = async () => {
        if (!window.ethereum) return;
        setActionLoading(true);
        try {
            const provider = new BrowserProvider(window.ethereum);
            const signer = await provider.getSigner();
            const usdc = new Contract(MOCK_USDC_ADDRESS, MockERC20ABI.abi, signer);
            const userAddr = await signer.getAddress();

            // Mint 10,000 USDC
            const tx = await usdc.mint(userAddr, parseUnits("10000", 6));
            await tx.wait();

            alert("Minted 10,000 MockUSDC!");
            fetchData();
        } catch (e: any) {
            console.error(e);
            alert("Faucet failed: " + e.message);
        } finally {
            setActionLoading(false);
        }
    };

    // 1. Fund Escrow (Creator)
    const handleFund = async () => {
        if (!window.ethereum) return;
        setActionLoading(true);
        try {
            const provider = new BrowserProvider(window.ethereum);
            const signer = await provider.getSigner();
            const usdc = new Contract(MOCK_USDC_ADDRESS, MockERC20ABI.abi, signer);
            const contract = new Contract(address, VercrowEscrowABI.abi, signer);

            // Approve
            // Note: In real app check allowance first
            const amountWei = await contract.amount();
            const txApprove = await usdc.approve(address, amountWei);
            await txApprove.wait();

            // Deposit
            const txFund = await contract.fundEscrow();
            await txFund.wait();

            alert("Funded successfully!");
            fetchData();
        } catch (e: any) {
            console.error(e);
            alert("Funding failed: " + e.message);
        } finally {
            setActionLoading(false);
        }
    };

    // 2. Simulate Proof (Demo)
    const handleSimulateProof = async (conditionIndex: number, val: number) => {
        setActionLoading(true);
        try {
            const provider = new BrowserProvider(window.ethereum);
            const signer = await provider.getSigner();
            const contract = new Contract(address, VercrowEscrowABI.abi, signer);

            // Generate fake hash
            const proofHash = ethers.keccak256(ethers.toUtf8Bytes("proof-" + Date.now()));

            const tx = await contract.submitProof(conditionIndex, val, proofHash);
            await tx.wait();

            alert("Proof submitted!");
            fetchData();
        } catch (e: any) {
            console.error(e);
            alert("Proof failed: " + e.message);
        } finally {
            setActionLoading(false);
        }
    };

    // 3. Release Funds
    const handleRelease = async () => {
        setActionLoading(true);
        try {
            const provider = new BrowserProvider(window.ethereum);
            const signer = await provider.getSigner();
            const contract = new Contract(address, VercrowEscrowABI.abi, signer);

            const tx = await contract.release();
            await tx.wait();

            alert("Funds Released! 🚀");
            fetchData();
        } catch (e: any) {
            console.error(e);
            alert("Release failed: " + e.message);
        } finally {
            setActionLoading(false);
        }
    };

    if (loading) return (
        <div className="min-h-screen bg-black text-white flex items-center justify-center">
            <Loader2 className="w-10 h-10 animate-spin text-indigo-500" />
        </div>
    );

    if (!escrow) return (
        <div className="min-h-screen bg-black text-white pt-32 text-center">
            <h1 className="text-2xl">Escrow Not Found</h1>
        </div>
    );

    return (
        <div className="min-h-screen bg-black text-white">
            <Navbar />
            <div className="pt-24 max-w-7xl mx-auto px-4 pb-20">

                {/* Header */}
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
                    <div>
                        <div className="flex items-center gap-3">
                            <h1 className="text-3xl font-bold">Escrow #{address?.slice(0, 6)}</h1>
                            <span className={`px-3 py-1 rounded-full text-xs font-bold ${COLORS[escrow.stateIdx] || "bg-gray-600"}`}>
                                {escrow.state}
                            </span>
                        </div>
                        <p className="text-gray-400 font-mono text-sm mt-1">{address}</p>
                    </div>
                    <div className="text-right flex items-center gap-6">
                        <button
                            onClick={() => setDemoMode(!demoMode)}
                            className={`px-4 py-2 rounded-full border text-sm font-bold flex items-center gap-2 transition ${demoMode ? "bg-indigo-500/20 border-indigo-500 text-indigo-400" : "bg-white/5 border-white/10 text-gray-400"}`}
                        >
                            {demoMode ? <ShieldCheck className="w-4 h-4" /> : <Box className="w-4 h-4" />}
                            {demoMode ? "Demo Mode ON" : "Real Mode"}
                        </button>
                        <div>
                            <p className="text-gray-400 text-sm uppercase">Locked Value</p>
                            <p className="text-4xl font-mono font-bold text-white">{escrow.amount} <span className="text-lg text-gray-500">USDC</span></p>
                        </div>
                    </div>
                </div>

                {demoMode && (
                    <div className="mb-8 p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-lg flex items-center gap-3">
                        <div className="p-2 bg-yellow-500/20 rounded-full">
                            <AlertTriangle className="w-5 h-5 text-yellow-500" />
                        </div>
                        <div className="flex-1">
                            <h4 className="text-sm font-bold text-yellow-500">🎥 Recording for Hackathon?</h4>
                            <p className="text-xs text-yellow-200/70">
                                MetaMask popups often appear <strong>black</strong> in screen recordings.
                                <br />To fix this: Open MetaMask Extension &rarr; Click 3 dots &rarr; Select <strong>"Expand View"</strong>.
                            </p>
                        </div>
                    </div>
                )}

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">

                    {/* Left: Conditions */}
                    <div className="space-y-6">
                        <div className="bg-white/5 border border-white/10 rounded-xl p-6">
                            <h3 className="text-lg font-bold mb-4 flex items-center gap-2"><FileText className="w-5 h-5" /> Policy Conditions</h3>
                            <div className="space-y-4">
                                {conditions.map((c: any) => {
                                    const proof = proofs.find(p => p.index === c.index);
                                    return (
                                        <div key={c.index} className="flex items-center gap-3 p-3 rounded-lg bg-black/40 border border-white/5">
                                            {proof ? <CheckCircle2 className="w-5 h-5 text-green-500" /> : <Clock className="w-5 h-5 text-gray-500" />}
                                            <div className="flex-1">
                                                <p className="text-sm font-bold">
                                                    {c.type === 0 ? "Delivery Confirmed" : c.type === 1 ? "Quality Score" : "Custom Condition"}
                                                </p>
                                                <p className="text-xs text-gray-500">
                                                    Operator: {c.operator === 0 ? "=" : c.operator === 1 ? ">=" : "<="} {c.value}
                                                </p>
                                            </div>
                                            {proof && (
                                                <div className="text-xs text-right text-gray-400">
                                                    <p>Val: {proof.value}</p>
                                                </div>
                                            )}
                                        </div>
                                    );
                                })}
                            </div>
                        </div>

                        {/* Actions Panel */}
                        <div className="bg-gradient-to-br from-indigo-900/20 to-purple-900/20 border border-indigo-500/30 rounded-xl p-6">
                            <h3 className="text-lg font-bold mb-4 flex items-center gap-2 text-indigo-300"><Box className="w-5 h-5" /> Actions</h3>

                            <div className="space-y-3">
                                {/* Actions */}
                                <div className="grid grid-cols-1 gap-4 mb-4">
                                    {/* Fund Card */}
                                    {escrow.state === "PENDING" && (
                                        <div className="glass p-6 rounded-xl border border-white/10 relative overflow-hidden group">
                                            <h2 className="text-xl font-bold mb-2 flex items-center gap-2">
                                                <Wallet className="w-5 h-5 text-indigo-400" />
                                                Fund Escrow
                                            </h2>
                                            <p className="text-gray-400 text-sm mb-4">
                                                Lock {escrow.amount} USDC in the smart contract.
                                            </p>

                                            <div className="flex gap-3">
                                                <button
                                                    onClick={handleFund}
                                                    disabled={actionLoading}
                                                    className="flex-1 bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-700 disabled:cursor-not-allowed text-white font-bold py-3 rounded-xl transition-all flex items-center justify-center gap-2"
                                                >
                                                    {actionLoading ? <Loader2 className="animate-spin" /> : "Fund Escrow"}
                                                </button>
                                                {demoMode && (
                                                    <button
                                                        onClick={handleFaucet}
                                                        disabled={actionLoading}
                                                        className="px-4 py-3 bg-white/10 hover:bg-white/20 rounded-xl font-bold transition flex items-center gap-2"
                                                        title="Get Test USDC"
                                                    >
                                                        <Coins className="w-5 h-5 text-yellow-400" />
                                                    </button>
                                                )}
                                            </div>
                                        </div>
                                    )}

                                    {/* Release Button */}
                                    {escrow.state === "VERIFYING" && escrow.proofsCount >= conditions.length && (
                                        <button
                                            onClick={handleRelease}
                                            disabled={actionLoading}
                                            className="w-full py-3 bg-green-600 hover:bg-green-700 rounded-lg font-bold transition flex items-center justify-center gap-2"
                                        >
                                            {actionLoading ? <Loader2 className="animate-spin" /> : "Release Funds"}
                                        </button>
                                    )}

                                    {/* Simulators (For Demo) */}
                                    {/* AI Agent Simulation (Demo Mode Only) */}
                                    {demoMode && (escrow.state === "LOCKED" || escrow.state === "VERIFYING") && (
                                        <div className="mt-4 pt-6 border-t border-white/10 space-y-6">
                                            <div className="flex items-center gap-2 mb-2">
                                                <div className="bg-indigo-500/20 p-2 rounded-lg">
                                                    <Box className="w-5 h-5 text-indigo-400" />
                                                </div>
                                                <div>
                                                    <h4 className="font-bold text-indigo-200">AI Agent Network</h4>
                                                    <p className="text-xs text-indigo-400">Upload evidence for autonomous verification</p>
                                                </div>
                                            </div>

                                            {conditions.map((c: any) => {
                                                const proof = proofs.find(p => p.index === c.index);
                                                // Local state for this condition's simulation (handled by a sub-component concept map or just tracked locally?
                                                // Ideally we'd separate this into a component, but for speed, we'll inline the logic with a helper or just localized state if we could.
                                                // Since we can't easily add per-item state without extracting a component, we will use a "simulating" map state in the parent.
                                                return (
                                                    <AgentSimulator
                                                        key={c.index}
                                                        condition={c}
                                                        proof={proof}
                                                        onSimulate={(val) => handleSimulateProof(c.index, val)}
                                                    />
                                                );
                                            })}

                                            {conditions.every((c: any) => proofs.find(p => p.index === c.index)) && (
                                                <div className="flex items-center gap-2 text-green-400 bg-green-500/10 p-3 rounded-lg border border-green-500/20">
                                                    <CheckCircle2 className="w-5 h-5" />
                                                    <span className="text-sm font-bold">All conditions verified by AI Agents. ready for release.</span>
                                                </div>
                                            )}
                                        </div>
                                    )}

                                    {escrow.state === "RELEASED" && (
                                        <div className="text-green-400 font-bold text-center py-2 border border-green-500/20 rounded bg-green-500/10">
                                            Transaction Complete ✅
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>

                        {/* Right: Timeline */}
                        <div className="lg:col-span-2 space-y-6">
                            <div className="bg-white/5 border border-white/10 rounded-xl p-8 min-h-[400px]">
                                <h3 className="text-lg font-bold mb-6">Proof & Event Timeline</h3>

                                <div className="relative border-l-2 border-white/10 ml-3 space-y-8 pl-8 pb-4">
                                    {/* Creation Event */}
                                    <div className="relative">
                                        <div className="absolute -left-[39px] w-5 h-5 rounded-full bg-gray-600 border-4 border-black" />
                                        <p className="text-xs text-gray-500 mb-1">Creation</p>
                                        <p className="font-bold">Escrow Initialized</p>
                                        <p className="text-sm text-gray-400 inline-block bg-white/5 px-2 py-1 rounded mt-1">{escrow.address}</p>
                                    </div>

                                    {escrow.stateIdx >= 1 && (
                                        <motion.div initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} className="relative">
                                            <div className="absolute -left-[39px] w-5 h-5 rounded-full bg-indigo-500 border-4 border-black" />
                                            <p className="text-xs text-gray-500 mb-1">Funding</p>
                                            <p className="font-bold text-indigo-300">Funds Locked</p>
                                            <p className="text-sm text-gray-400 mt-1">{escrow.amount} USDC secured in contract.</p>
                                        </motion.div>
                                    )}

                                    {proofs.map((p, i) => (
                                        <motion.div initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.1 }} key={i} className="relative">
                                            <div className="absolute -left-[39px] w-5 h-5 rounded-full bg-yellow-500 border-4 border-black" />
                                            <p className="text-xs text-gray-500 mb-1">Verification</p>
                                            <p className="font-bold text-yellow-300">Proof Submitted</p>
                                            <p className="text-sm text-gray-400 mt-1 font-mono">
                                                Condition #{p.index} • Value: {p.value} • Source: {p.source.slice(0, 6)}...
                                            </p>
                                        </motion.div>
                                    ))}

                                    {escrow.state === "RELEASED" && (
                                        <motion.div initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} className="relative">
                                            <div className="absolute -left-[39px] w-5 h-5 rounded-full bg-green-500 border-4 border-black" />
                                            <p className="text-xs text-gray-500 mb-1">Settlement</p>
                                            <p className="font-bold text-green-400">Funds Released</p>
                                            <p className="text-sm text-gray-400 mt-1">Beneficiary {escrow.beneficiary.slice(0, 6)}... received payment.</p>
                                        </motion.div>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

// --- Sub-component for Agent Simulation ---
function AgentSimulator({ condition, proof, onSimulate }: { condition: any, proof: any, onSimulate: (val: number) => void }) {
    const [status, setStatus] = useState<"idle" | "analyzing" | "verified">("idle");
    const [file, setFile] = useState<File | null>(null);

    if (proof) {
        return (
            <div className="bg-green-900/10 border border-green-500/30 rounded-lg p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-green-500" />
                    <div>
                        <p className="text-sm font-bold text-green-300">
                            {condition.type === 0 ? "Delivery Agent" : "Quality Control AI"}
                        </p>
                        <p className="text-xs text-green-500/70">Verified & On-Chain</p>
                    </div>
                </div>
            </div>
        );
    }

    const handleUpload = (e: any) => {
        if (e.target.files?.[0]) {
            setFile(e.target.files[0]);
            setStatus("analyzing");
            // Simulate AI delay
            setTimeout(() => {
                setStatus("verified");
            }, 3000);
        }
    };

    return (
        <div className="bg-black/40 border border-white/10 rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                    {condition.type === 0 ? <Box className="w-4 h-4 text-blue-400" /> : <ShieldCheck className="w-4 h-4 text-purple-400" />}
                    <span className="text-sm font-bold text-gray-300">
                        {condition.type === 0 ? "Delivery Evidence" : "Quality Inspection"}
                    </span>
                </div>
                <span className="text-xs px-2 py-0.5 rounded bg-white/5 text-gray-500 border border-white/5">
                    Waiting for input
                </span>
            </div>

            {status === "idle" && (
                <div className="relative group">
                    <input
                        type="file"
                        onChange={handleUpload}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                    />
                    <div className="w-full border-2 border-dashed border-white/20 rounded-lg p-4 text-center hover:border-indigo-500/50 hover:bg-indigo-500/5 transition">
                        <UploadCloud className="w-6 h-6 text-gray-400 mx-auto mb-2 group-hover:text-indigo-400" />
                        <p className="text-xs text-gray-400 group-hover:text-indigo-300">
                            Click to upload {condition.type === 0 ? "shipping label / photo" : "inspection report"}
                        </p>
                    </div>
                </div>
            )}

            {status === "analyzing" && (
                <div className="space-y-2 animate-pulse">
                    <div className="flex items-center gap-2 text-xs text-indigo-300">
                        <Loader2 className="w-3 h-3 animate-spin" />
                        Gemini AI analyzing document...
                    </div>
                    <div className="h-1.5 bg-gray-700 rounded-full overflow-hidden">
                        <motion.div
                            initial={{ width: "0%" }}
                            animate={{ width: "100%" }}
                            transition={{ duration: 2.5 }}
                            className="h-full bg-indigo-500"
                        />
                    </div>
                    <p className="text-[10px] text-gray-500 font-mono pl-5">
                        {">"} Extracting data points...<br />
                        {">"} Verifying signatures...<br />
                        {">"} Matching intent requirements...
                    </p>
                </div>
            )}

            {status === "verified" && (
                <div className="space-y-3">
                    <div className="flex items-center gap-2 text-xs text-green-400 bg-green-900/20 p-2 rounded border border-green-500/20">
                        <CheckCircle2 className="w-4 h-4" />
                        <span>AI Analysis Complete: <strong>MATCH</strong></span>
                    </div>
                    <button
                        onClick={() => onSimulate(condition.value)}
                        className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded flex items-center justify-center gap-2 transition"
                    >
                        <ShieldCheck className="w-3 h-3" />
                        Submit Proof to Blockchain
                    </button>
                </div>
            )}
        </div>
    );
}
