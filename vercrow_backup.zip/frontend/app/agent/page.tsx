"use client";

import { useState, useRef, useEffect } from "react";
import Navbar from "@/components/Navbar";
import { BACKEND_URL } from "@/utils/constants";
import { Loader2, Truck, ShieldCheck, Activity, Server, Radio, Database, Terminal } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

type AgentStatus = "idle" | "listening" | "processing" | "complete" | "error";

export default function MCPOrchestrator() {
    const [escrowId, setEscrowId] = useState("");
    const [logs, setLogs] = useState<string[]>([]);

    // Agent States
    const [deliveryStatus, setDeliveryStatus] = useState<AgentStatus>("listening");
    const [qualityStatus, setQualityStatus] = useState<AgentStatus>("listening");
    const [qualityScore, setQualityScore] = useState(95);

    const addLog = (agent: string, msg: string) => {
        const time = new Date().toLocaleTimeString();
        setLogs(prev => [`[${time}] ${agent}: ${msg}`, ...prev]);
    };

    const handleDelivery = async () => {
        if (!escrowId) return;
        setDeliveryStatus("processing");
        addLog("DeliveryMCP", "Received trigger event. Initiating FedEx API lookup...");

        // Simulation steps
        await new Promise(r => setTimeout(r, 1000));
        addLog("DeliveryMCP", "📡 Fetching GPS coordinates from sensor #4912...");

        await new Promise(r => setTimeout(r, 1000));
        addLog("DeliveryMCP", "📦 Verifying package signature matches Intent NFT...");

        try {
            const res = await fetch(`${BACKEND_URL}/api/confirm-delivery`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    escrowAddress: escrowId, // User inputs address as ID
                    escrowId: 0 // Legacy/Unused if address is unique instance
                })
            });
            const data = await res.json();

            if (data.success) {
                addLog("DeliveryMCP", "✅ Proof generated and submitted on-chain. Tx: " + data.hash.slice(0, 10));
                setDeliveryStatus("complete");
                // Reset after delay
                setTimeout(() => setDeliveryStatus("listening"), 5000);
            } else throw new Error(data.error);
        } catch (e: any) {
            addLog("DeliveryMCP", "❌ Error: " + e.message);
            setDeliveryStatus("error");
        }
    };

    const handleQuality = async () => {
        if (!escrowId) return;
        setQualityStatus("processing");
        addLog("QualityMCP", "Trigger received. Activating Computer Vision module...");

        // Simulation
        await new Promise(r => setTimeout(r, 1500));
        addLog("QualityMCP", "📸 Analyzing 24 product images for defects...");

        await new Promise(r => setTimeout(r, 1500));
        addLog("QualityMCP", "🔬 Running ISO-9001 compliance algorithm...");
        addLog("QualityMCP", `📊 Calculated Quality Score: ${qualityScore}/100`);

        try {
            const res = await fetch(`${BACKEND_URL}/api/submit-quality`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    escrowAddress: escrowId,
                    escrowId: 0,
                    score: qualityScore
                })
            });
            const data = await res.json();

            if (data.success) {
                addLog("QualityMCP", "✅ Quality Proof minted. Validator contract updated.");
                setQualityStatus("complete");
                setTimeout(() => setQualityStatus("listening"), 5000);
            } else throw new Error(data.error);
        } catch (e: any) {
            addLog("QualityMCP", "❌ Error: " + e.message);
            setQualityStatus("error");
        }
    };

    return (
        <div className="min-h-screen bg-black text-white font-mono">
            <Navbar />
            <div className="pt-24 max-w-7xl mx-auto px-4 pb-12">

                {/* Header */}
                <div className="flex justify-between items-end mb-8 border-b border-gray-800 pb-4">
                    <div>
                        <h1 className="text-3xl font-bold text-white flex items-center gap-3">
                            <Server className="text-indigo-500" />
                            MCP Orchestrator
                        </h1>
                        <p className="text-gray-500 mt-1">Autonomous Agent Network • v2.1.0 • Active</p>
                    </div>
                    <div className="flex gap-4 items-center">
                        <div className="flex items-center gap-2 text-xs text-green-400 bg-green-900/20 px-3 py-1 rounded-full border border-green-500/20">
                            <Activity className="w-3 h-3 animate-pulse" /> System Nominal
                        </div>
                    </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">

                    {/* Main Controls */}
                    <div className="lg:col-span-2 space-y-6">

                        {/* Target Input */}
                        <div className="bg-[#0A0A0A] border border-gray-800 p-6 rounded-xl flex items-center gap-4">
                            <label className="text-gray-400 whitespace-nowrap">Target Contract ID:</label>
                            <input
                                type="text"
                                value={escrowId}
                                onChange={e => setEscrowId(e.target.value)}
                                placeholder="Escrow ID (e.g. 0)"
                                className="flex-1 bg-black border border-gray-700 p-2 rounded text-indigo-400 focus:border-indigo-500 outline-none"
                            />
                        </div>

                        {/* Agents Grid */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

                            {/* Delivery Agent */}
                            <AgentCard
                                name="Delivery Verification MCP"
                                icon={Truck}
                                color="blue"
                                status={deliveryStatus}
                                dataSource="FedEx Express API (Mock)"
                                onRun={handleDelivery}
                            />

                            {/* Quality Agent */}
                            <AgentCard
                                name="Vision Quality MCP"
                                icon={ShieldCheck}
                                color="purple"
                                status={qualityStatus}
                                dataSource="cv2.analyze_image()"
                                onRun={handleQuality}
                            >
                                <div className="mt-4 flex items-center gap-2 bg-black/40 p-2 rounded border border-white/5">
                                    <span className="text-xs text-gray-500">Target Score:</span>
                                    <input
                                        type="number"
                                        value={qualityScore}
                                        onChange={e => setQualityScore(Number(e.target.value))}
                                        className="w-16 bg-transparent text-right text-purple-400 outline-none"
                                    />
                                    <span className="text-xs text-gray-600">/100</span>
                                </div>
                            </AgentCard>

                        </div>

                    </div>

                    {/* Logs Panel */}
                    <div className="bg-[#0A0A0A] border border-gray-800 rounded-xl overflow-hidden flex flex-col h-[600px]">
                        <div className="bg-gray-900/50 p-3 border-b border-gray-800 flex justify-between items-center">
                            <span className="text-xs font-bold text-gray-400 flex items-center gap-2"><Terminal className="w-4 h-4" /> Live Execution Log</span>
                            <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                        </div>
                        <div className="flex-1 p-4 font-mono text-xs overflow-y-auto space-y-3 font-light">
                            {logs.length === 0 && <span className="text-gray-700 italic">...waiting for signals...</span>}
                            {logs.map((log, i) => (
                                <div key={i} className="text-gray-300 break-words border-l-2 border-indigo-500/20 pl-2">
                                    {log}
                                </div>
                            ))}
                        </div>
                    </div>

                </div>
            </div>
        </div>
    );
}

function AgentCard({ name, icon: Icon, color, status, dataSource, onRun, children }: any) {
    const isProcessing = status === "processing";
    const isComplete = status === "complete";

    return (
        <div className={`relative overflow-hidden bg-[#0A0A0A] border p-6 rounded-xl transition-all ${isProcessing ? `border-${color}-500 shadow-[0_0_30px_-5px_var(--tw-shadow-color)] shadow-${color}-500/20` : "border-gray-800"}`}>
            {isProcessing && (
                <div className={`absolute top-0 left-0 w-full h-1 bg-${color}-500/20`}>
                    <div className={`h-full bg-${color}-500 animate-loading-bar`} />
                </div>
            )}

            <div className="flex justify-between items-start mb-6">
                <div className={`p-3 rounded-lg bg-${color}-500/10`}>
                    <Icon className={`w-6 h-6 text-${color}-500`} />
                </div>
                <div className={`px-2 py-1 rounded text-[10px] bg-${color}-900/20 border border-${color}-500/20 text-${color}-300 uppercase`}>
                    {status}
                </div>
            </div>

            <h3 className="font-bold text-lg mb-1">{name}</h3>
            <div className="flex items-center gap-2 text-xs text-gray-500 mb-6">
                <Database className="w-3 h-3" /> Source: {dataSource}
            </div>

            {children}

            <button
                onClick={onRun}
                disabled={status !== "listening" && status !== "complete" && status !== "error"}
                className={`w-full py-3 rounded-lg font-bold text-sm flex items-center justify-center gap-2 transition-all mt-4 ${isComplete
                    ? "bg-green-600 text-white hover:bg-green-500"
                    : `bg-${color}-600 hover:bg-${color}-500 text-white`
                    } disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer`}
            >
                {isProcessing ? (
                    <Loader2 className="animate-spin w-4 h-4" />
                ) : isComplete ? (
                    "Task Complete"
                ) : (
                    "Init Sequence"
                )}
            </button>
        </div>
    );
}
