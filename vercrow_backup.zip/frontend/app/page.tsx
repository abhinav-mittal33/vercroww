"use client";

import Link from "next/link";
import { ArrowRight, ShieldCheck, Zap, Activity, MousePointerClick, BrainCircuit, Lock } from "lucide-react";
import { motion } from "framer-motion";
import Navbar from "@/components/Navbar";

export default function Home() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.2 }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 }
  };

  return (
    <div className="min-h-screen bg-black text-white overflow-hidden selection:bg-indigo-500/30">
      <Navbar />

      {/* Hero Section */}
      <div className="relative pt-32 pb-20 sm:pt-40 sm:pb-24 overflow-hidden">
        {/* Abstract Background Gradients */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[600px] bg-indigo-600/20 rounded-full blur-[120px] -z-10" />
        <div className="absolute bottom-0 right-0 w-[800px] h-[600px] bg-purple-600/10 rounded-full blur-[100px] -z-10" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-sm text-indigo-300 mb-8 backdrop-blur-sm">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-indigo-500"></span>
              </span>
              Live on Sepolia Testnet
            </div>

            <h1 className="text-5xl md:text-7xl font-bold tracking-tight mb-8 bg-clip-text text-transparent bg-gradient-to-r from-white via-indigo-200 to-indigo-400">
              Autonomous Escrow with <br className="hidden md:block" /> Cryptographic Guarantees
            </h1>

            <p className="mt-4 text-xl text-gray-400 max-w-3xl mx-auto mb-10 leading-relaxed">
              Define your terms in plain English. <span className="text-indigo-400 font-semibold">AI executes.</span> Policy enforces. <span className="text-indigo-400 font-semibold">Blockchain proves.</span>
              <br />The first escrow system that doesn't rely on human intermediaries.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Link href="/create">
                <button className="group relative px-8 py-4 bg-white text-black rounded-full font-bold text-lg hover:bg-gray-100 transition-all flex items-center gap-2 shadow-[0_0_40px_-10px_rgba(255,255,255,0.3)] hover:shadow-[0_0_60px_-15px_rgba(255,255,255,0.5)]">
                  Create Escrow
                  <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </button>
              </Link>
              <Link href="/dashboard">
                <button className="px-8 py-4 rounded-full font-medium text-white border border-white/20 hover:bg-white/10 transition-colors backdrop-blur-sm">
                  View Dashboard
                </button>
              </Link>
            </div>
          </motion.div>
        </div>
      </div>

      {/* How It Works */}
      <div className="py-24 bg-white/5 border-y border-white/5 relative backdrop-blur-3xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-white mb-4">How It Works</h2>
            <p className="text-gray-400">Three steps to autonomous trust.</p>
          </div>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid grid-cols-1 md:grid-cols-3 gap-8"
          >
            {[
              { icon: BrainCircuit, title: "1. Describe Intent", desc: "Type your deal in plain English. Our LLM parses it into structured policy logic." },
              { icon: shieldCheckIcon, title: "2. Validate & Lock", desc: "Policy Contract validates terms and mints an Intent NFT. You deposit funds." },
              { icon: Zap, title: "3. Auto-Execute", desc: "AI Agents verify delivery & quality off-chain. Smart Contract releases funds instantly." }
            ].map((step, idx) => (
              <motion.div key={idx} variants={itemVariants} className="bg-black/40 p-8 rounded-2xl border border-white/10 hover:border-indigo-500/50 transition-colors group">
                <div className="w-12 h-12 bg-indigo-500/10 rounded-xl flex items-center justify-center mb-6 group-hover:bg-indigo-500/20 transition-colors">
                  <step.icon className="w-6 h-6 text-indigo-400" />
                </div>
                <h3 className="text-xl font-bold mb-3">{step.title}</h3>
                <p className="text-gray-400 leading-relaxed">{step.desc}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>

      {/* Features Grid */}
      <div className="py-24 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-white mb-4">Why Vercrow?</h2>
            <p className="text-gray-400">Built for the agentic future.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { icon: Lock, title: "Policy-Gated", desc: "Every action is validated against on-chain immutable rules." },
              { icon: Activity, title: "Autonomous", desc: "Agents work 24/7 to verify events without human bias." },
              { icon: ShieldCheck, title: "Provable", desc: "Complete cryptographic audit trail of every decision." },
              { icon: Zap, title: "Lightning Fast", desc: "Settlement in seconds, not weeks. No paperwork." }
            ].map((feature, idx) => (
              <div key={idx} className="p-6 rounded-2xl bg-gradient-to-b from-white/5 to-transparent border border-white/10 hover:border-white/20 transition-all">
                <feature.icon className="w-8 h-8 text-indigo-400 mb-4" />
                <h3 className="text-lg font-bold mb-2">{feature.title}</h3>
                <p className="text-sm text-gray-400">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* CTA */}
      <div className="py-20 text-center">
        <div className="max-w-3xl mx-auto px-4">
          <h2 className="text-4xl font-bold mb-8">Ready to replace the middleman?</h2>
          <Link href="/create">
            <button className="px-10 py-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold text-lg transition-all shadow-lg hover:shadow-indigo-500/25">
              Try Demo Now
            </button>
          </Link>
        </div>
      </div>
    </div>
  );
}

const shieldCheckIcon = ShieldCheck; // Fix validation in loop
