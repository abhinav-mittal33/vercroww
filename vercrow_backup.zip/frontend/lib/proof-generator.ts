
import { ethers } from "ethers";

// Mock Types
export type Proof = {
    conditionType: number;
    value: number;
    proofHash: string;
    timestamp: number;
    source: string;
};

// Simulate Delivery MCP
export const simulateDeliveryProof = async (): Promise<Proof> => {
    // Simulate API Latency
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Generate random data
    const timestamp = Math.floor(Date.now() / 1000);
    const value = 1; // True

    // Hash: keccak256(type, value, timestamp)
    // In real app, this would be signed by the agent's private key
    const payload = ethers.AbiCoder.defaultAbiCoder().encode(
        ["uint8", "uint256", "uint256"],
        [0, value, timestamp]
    );
    const proofHash = ethers.keccak256(payload);

    return {
        conditionType: 0,
        value,
        timestamp,
        proofHash,
        source: "DeliveryMCP_Node_01"
    };
};

// Simulate Quality MCP
export const simulateQualityProof = async (): Promise<Proof> => {
    await new Promise(resolve => setTimeout(resolve, 3000));

    const timestamp = Math.floor(Date.now() / 1000);
    // Random score between 85 and 100
    const value = Math.floor(Math.random() * (100 - 85 + 1) + 85);

    const payload = ethers.AbiCoder.defaultAbiCoder().encode(
        ["uint8", "uint256", "uint256"],
        [1, value, timestamp]
    );
    const proofHash = ethers.keccak256(payload);

    return {
        conditionType: 1,
        value,
        timestamp,
        proofHash,
        source: "QualityMCP_Vision_AI"
    };
};
