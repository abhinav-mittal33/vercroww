"use client";

import { useState } from "react";
import { ShieldAlert, Ban, AlertTriangle, CheckCircle2, Lock, X, ShieldCheck } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export function AttackDemo() {
    const [isOpen, setIsOpen] = useState(false);
    const [attackState, setAttackState] = useState<"idle" | "attacking" | "blocked">("idle");
    const [scenario, setScenario] = useState("");
    const [log, setLog] = useState("");

    const runAttack = (name: string, message: string) => {
        setScenario(name);
        setAttackState("attacking");
        setLog("Initiating exploit vector...");

        setTimeout(() => {
            setLog("Attempting unauthorized state transition...");
        }, 1000);

        setTimeout(() => {
            setAttackState("blocked");
            setLog(message);
        }, 2000);
    };

    const reset = () => {
        setAttackState("idle");
        setLog("");
    };

    if (!isOpen) return (
        <button
            onClick={() => setIsOpen(true)}
            className="fixed bottom-8 right-8 bg-red-900/80 hover:bg-red-800 text-red-200 border border-red-500/50 px-4 py-2 rounded-full font-bold flex items-center gap-2 shadow-[0_0_20px_rgba(239,68,68,0.4)] backdrop-blur-md z-50 transition-all hover:scale-105"
        >
            <ShieldAlert className="w-5 h-5" /> Test Security
        </button>
    );

    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="bg-black border border-red-900/50 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl"
            >
                {/* Header */}
                <div className="bg-red-950/30 p-6 border-b border-red-900/30 flex justify-between items-center">
                    <div className="flex items-center gap-3">
                        <ShieldAlert className="w-8 h-8 text-red-500" />
                        <div>
                            <h2 className="text-xl font-bold text-white">Vercrow Security Environment</h2>
                            <p className="text-red-300/60 text-xs uppercase tracking-wider">Penetration Testing Mode</p>
                        </div>
                    </div>
                    <button onClick={() => setIsOpen(false)} className="text-gray-500 hover:text-white"><X /></button>
                </div>

                {/* Body */}
                <div className="p-8 grid grid-cols-1 md:grid-cols-2 gap-8">

                    {/* Controls */}
                    <div className="space-y-4">
                        <h3 className="text-gray-400 text-sm font-bold uppercase mb-4">Attack Scenarios</h3>

                        <button
                            onClick={() => runAttack("Beneficiary Spoofing", "❌ Transaction Reverted: Only Buyer/Seller modifier enforced.")}
                            disabled={attackState === "attacking"}
                            className="w-full p-4 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-left flex items-center gap-3 transition-colors"
                        >
                            <div className="bg-red-500/10 p-2 rounded-lg"><Ban className="w-5 h-5 text-red-400" /></div>
                            <div>
                                <p className="font-bold text-gray-200">Spoof Beneficiary</p>
                                <p className="text-xs text-gray-500">Try to release funds to attacker wallet</p>
                            </div>
                        </button>

                        <button
                            onClick={() => runAttack("Fake Proof Injection", "❌ Invalid Signature: Keccak256 hash mismatch with Intent.")}
                            disabled={attackState === "attacking"}
                            className="w-full p-4 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-left flex items-center gap-3 transition-colors"
                        >
                            <div className="bg-orange-500/10 p-2 rounded-lg"><AlertTriangle className="w-5 h-5 text-orange-400" /></div>
                            <div>
                                <p className="font-bold text-gray-200">Inject Fake Proof</p>
                                <p className="text-xs text-gray-500">Bypass Oracle verification logic</p>
                            </div>
                        </button>

                        <button
                            onClick={() => runAttack("Double Spend", "❌ State Error: Escrow already RELEASED.")}
                            disabled={attackState === "attacking"}
                            className="w-full p-4 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-left flex items-center gap-3 transition-colors"
                        >
                            <div className="bg-yellow-500/10 p-2 rounded-lg"><Lock className="w-5 h-5 text-yellow-400" /></div>
                            <div>
                                <p className="font-bold text-gray-200">Double Spend</p>
                                <p className="text-xs text-gray-500">Attempt re-entrancy on withdraw</p>
                            </div>
                        </button>
                    </div>

                    {/* Console Output */}
                    <div className="bg-black border border-white/10 rounded-xl p-4 font-mono text-sm relative overflow-hidden flex flex-col">
                        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-red-500/50 to-transparent opacity-50" />

                        <div className={`flex-1 flex flex-col items-center justify-center transition-opacity ${attackState === "idle" ? "opacity-100" : "opacity-0 absolute"}`}>
                            <ShieldCheck className="w-12 h-12 text-green-500/20 mb-2" />
                            <p className="text-gray-600">System Secure</p>
                        </div>

                        {attackState !== "idle" && (
                            <div className="space-y-2">
                                <p className="text-gray-400">$ exec attack_module --target {scenario}</p>
                                <p className="text-yellow-500 animate-pulse">{attackState === "attacking" ? "Running exploit..." : "Exploit Attempted"}</p>
                                {log && <p className="text-gray-300">&gt; {log.split(":")[0]}</p>}

                                {attackState === "blocked" && (
                                    <motion.div
                                        initial={{ scale: 0.8, opacity: 0 }}
                                        animate={{ scale: 1, opacity: 1 }}
                                        className="mt-4 p-3 bg-red-900/20 border border-red-500 text-red-400 rounded-lg text-xs"
                                    >
                                        {log}
                                    </motion.div>
                                )}
                            </div>
                        )}

                        {attackState === "blocked" && (
                            <button onClick={reset} className="mt-auto w-full py-2 bg-white/10 hover:bg-white/20 rounded text-xs uppercase tracking-wider">Reset Simulation</button>
                        )}
                    </div>
                </div>
            </motion.div>
        </div>
    );
}
