"use client";

import { useState, useEffect } from "react";
import { X, ArrowRight, User, CheckCircle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { usePathname, useRouter } from "next/navigation";
import { useDemo } from "@/context/DemoContext";

/**
 * Story Mode Component
 * A multi-page tutorial overlay that guides the judge through the demo flow.
 */
export function StoryMode() {
    const [isActive, setIsActive] = useState(false);
    const [step, setStep] = useState(0);
    const pathname = usePathname();
    const router = useRouter();
    const { toggleDemoMode, isDemoMode } = useDemo();

    const STEPS = [
        {
            title: "👋 Welcome to Vercrow",
            desc: "This is a guided tour of the first Agentic Escrow system. We'll show you how AI + Blockchain replaces the middleman.",
            path: "/",
            action: "Start Tour"
        },
        {
            title: "🤖 Activate Demo Mode",
            desc: "For this demo, we'll simulate the Seller automatically so you don't have to switch wallets. Look for the 'Demo Mode' badge.",
            path: "/",
            action: "Activate & Continue",
            onNext: () => { if (!isDemoMode) toggleDemoMode(); }
        },
        {
            title: "📝 Create an Intent",
            desc: "Let's create a deal. Click 'Create Escrow' to start. You won't need to code.",
            path: "/",
            action: "Go to Create",
            targetPath: "/create"
        },
        {
            title: "🧠 AI Negotiation",
            desc: "Type your request here. The AI will parse it into strict Policy Conditions (Delivery + Quality).",
            path: "/create",
            action: "Got it"
        },
        // More steps can be contextual based on path, but hard to force navigation without user interaction.
        // We will keep it simple: A persistent helper that updates based on where you are?
        // Or a strict wizard? The prompt asked for "Overlay tutorial... Step 1, Step 2..."
        // Let's implement a persistent "Guide Card" at bottom left.
    ];

    // Simple manual advancement for now
    const currentStep = STEPS[step];

    if (!isActive) return (
        <button
            onClick={() => setIsActive(true)}
            className="fixed bottom-8 left-8 bg-indigo-600 text-white px-6 py-3 rounded-full font-bold shadow-lg z-40 hover:scale-105 transition-transform flex items-center gap-2"
        >
            🎬 Story Mode
        </button>
    );

    const handleNext = () => {
        if (currentStep.onNext) currentStep.onNext();
        if (currentStep.targetPath) router.push(currentStep.targetPath);

        if (step < STEPS.length - 1) {
            setStep(s => s + 1);
        } else {
            setIsActive(false);
            setStep(0);
        }
    };

    return (
        <AnimatePresence>
            <motion.div
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                exit={{ y: 50, opacity: 0 }}
                className="fixed bottom-8 left-8 z-50 w-96 bg-black/90 border border-indigo-500/50 backdrop-blur-md rounded-2xl p-6 shadow-2xl"
            >
                <div className="flex justify-between items-start mb-4">
                    <div className="flex items-center gap-2 text-indigo-400 font-bold uppercase text-xs tracking-wider">
                        <span>Step {step + 1}/{STEPS.length}</span>
                    </div>
                    <button onClick={() => setIsActive(false)} className="text-gray-500 hover:text-white"><X className="w-4 h-4" /></button>
                </div>

                <h3 className="text-xl font-bold mb-2">{currentStep.title}</h3>
                <p className="text-gray-400 text-sm mb-6 leading-relaxed">
                    {currentStep.desc}
                </p>

                <div className="flex gap-2">
                    <button
                        onClick={handleNext}
                        className="flex-1 bg-white text-black py-2 rounded-lg font-bold hover:bg-gray-200 transition-colors flex items-center justify-center gap-2"
                    >
                        {currentStep.action} <ArrowRight className="w-4 h-4" />
                    </button>
                    {step > 0 && (
                        <button onClick={() => setStep(s => s - 1)} className="px-4 py-2 rounded-lg border border-white/10 hover:bg-white/5">
                            Before
                        </button>
                    )}
                </div>
            </motion.div>
        </AnimatePresence>
    );
}
