"use client";

import Link from "next/link";
import { useState } from "react";
import { Menu, X, ShieldCheck } from "lucide-react";
import { useDemo } from "@/context/DemoContext";

export default function Navbar() {
    const [isOpen, setIsOpen] = useState(false);

    return (
        <nav className="fixed w-full z-50 glass">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex items-center justify-between h-16">
                    <div className="flex items-center gap-2">
                        <ShieldCheck className="w-8 h-8 text-indigo-500" />
                        <Link href="/" className="font-bold text-xl tracking-tight">
                            Vercrow
                        </Link>
                    </div>
                    <div className="hidden md:block">
                        <div className="ml-10 flex items-center space-x-4">
                            <Link href="/" className="hover:text-indigo-400 px-3 py-2 rounded-md text-sm font-medium transition">
                                Home
                            </Link>
                            <Link href="/create" className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-md text-sm font-medium transition">
                                Create Escrow
                            </Link>
                            <Link href="/dashboard" className="hover:text-indigo-400 px-3 py-2 rounded-md text-sm font-medium transition">
                                Dashboard
                            </Link>
                            <div className="border-l border-white/20 h-6 mx-2" />
                            <DemoToggle />
                        </div>
                    </div>
                    <div className="-mr-2 flex md:hidden">
                        <DemoToggle />
                        <button
                            onClick={() => setIsOpen(!isOpen)}
                            className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-white hover:bg-gray-700 focus:outline-none"
                        >
                            {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
                        </button>
                    </div>
                </div>
            </div>
            {isOpen && (
                <div className="md:hidden glass">
                    <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
                        <Link href="/" className="block hover:text-indigo-400 px-3 py-2 rounded-md text-base font-medium">
                            Home
                        </Link>
                        <Link href="/create" className="block hover:text-indigo-400 px-3 py-2 rounded-md text-base font-medium">
                            Create Escrow
                        </Link>
                        <Link href="/dashboard" className="block hover:text-indigo-400 px-3 py-2 rounded-md text-base font-medium">
                            Dashboard
                        </Link>
                    </div>
                </div>
            )}
        </nav>
    );
}

function DemoToggle() {
    const { isDemoMode, toggleDemoMode } = useDemo();
    return (
        <button
            onClick={toggleDemoMode}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold border transition-all ${isDemoMode ? "bg-amber-500/20 border-amber-500 text-amber-500" : "bg-white/5 border-white/10 text-gray-400 hover:text-white"}`}
        >
            {isDemoMode ? "🤖 Demo Mode" : "👤 Real Mode"}
        </button>
    );
}
