"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { CheckCircle, Circle, Clock, Package, ShieldCheck, AlertCircle } from "lucide-react";
import { format } from "date-fns";

export default function EscrowCard({ escrow, onDeposit, onApprove, onRefund, userAddress }: any) {
    const STATUS_LABELS = [
        "Draft", "Approved", "Funded", "Delivered", "Verified", "Settled", "Refunded"
    ];

    const currentStatusIndex = Number(escrow.status);
    const isSeller = userAddress && escrow.seller.toLowerCase() === userAddress.toLowerCase();
    const isBuyer = userAddress && escrow.buyer.toLowerCase() === userAddress.toLowerCase();

    return (
        <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass p-6 rounded-2xl border border-white/5 relative overflow-hidden group"
        >
            {/* Status Badge */}
            <div className="absolute top-4 right-4">
                <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${currentStatusIndex === 5 ? "bg-green-500/20 text-green-400" :
                    currentStatusIndex === 6 ? "bg-red-500/20 text-red-400" :
                        "bg-indigo-500/20 text-indigo-400"
                    }`}>
                    {STATUS_LABELS[currentStatusIndex]}
                </span>
            </div>

            <div className="mb-6">
                <h3 className="text-2xl font-bold flex items-center gap-2">
                    <Package className="w-6 h-6 text-gray-400" />
                    {escrow.item} <span className="text-gray-500 text-lg">x{escrow.quantity}</span>
                </h3>
                <p className="text-gray-400 mt-1 flex items-center gap-2">
                    ID #{escrow.id.toString()} • Created {format(new Date(Number(escrow.createdAt) * 1000), 'MMM d, yyyy')}
                </p>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-6 text-sm">
                <div className="bg-white/5 p-3 rounded-lg">
                    <p className="text-gray-500 text-xs uppercase mb-1">Amount</p>
                    <p className="font-mono text-lg font-bold">{(Number(escrow.amount) / 1e6).toLocaleString()} USDC</p>
                </div>
                <div className="bg-white/5 p-3 rounded-lg">
                    <p className="text-gray-500 text-xs uppercase mb-1">Terms</p>
                    <div className="flex gap-2">
                        <span className="bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded text-xs flex items-center gap-1">
                            <Clock className="w-3 h-3" /> {escrow.deliveryDays}d
                        </span>
                        <span className="bg-purple-500/20 text-purple-300 px-2 py-0.5 rounded text-xs flex items-center gap-1">
                            <ShieldCheck className="w-3 h-3" /> Q{escrow.qualityThreshold}
                        </span>
                    </div>
                </div>
            </div>

            {/* Stepper */}
            <div className="flex items-center justify-between mb-6 relative">
                <div className="absolute h-1 w-full bg-white/5 top-1/2 -z-10 rounded-full" />
                {["Draft", "Funded", "Done"].map((label, idx) => {
                    // Simplified stepper logic
                    const stepIdx = idx * 2; // Roughly matching status index logic
                    const isActive = currentStatusIndex >= stepIdx; // Very rough approximation
                    return (
                        <div key={label} className="flex flex-col items-center gap-1 bg-black px-2">
                            {isActive ? <CheckCircle className="w-5 h-5 text-indigo-500" /> : <Circle className="w-5 h-5 text-gray-700" />}
                            <span className={`text-[10px] uppercase font-bold ${isActive ? "text-white" : "text-gray-700"}`}>{label}</span>
                        </div>
                    );
                })}
            </div>

            {/* Actions */}
            <div className="border-t border-white/10 pt-4 flex justify-end gap-3">
                {isSeller && currentStatusIndex === 0 && (
                    <button onClick={() => onApprove(escrow.id)} className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm font-bold transition">
                        Approve Request
                    </button>
                )}

                {isBuyer && currentStatusIndex === 1 && (
                    <button onClick={() => onDeposit(escrow.id)} className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-sm font-bold transition">
                        Deposit Funds
                    </button>
                )}

                {currentStatusIndex === 6 && (
                    <div className="flex items-center gap-2 text-red-400 text-sm">
                        <AlertCircle className="w-4 h-4" /> Refunded
                    </div>
                )}

                {currentStatusIndex === 5 && (
                    <div className="flex items-center gap-2 text-green-400 text-sm">
                        <CheckCircle className="w-4 h-4" /> Settled
                    </div>
                )}
            </div>
        </motion.div >
    );
}
