// Deployed Addresses (Localhost)
export const POLICY_VALIDATOR_ADDRESS = "0x5FC8d32690cc91D4c39d9d3abcBD16989F875707";
export const VERCROW_ESCROW_IMPLEMENTATION = "0x0165878A594ca255338adfa4d48449f69242Eb8F";
export const MOCK_USDC_ADDRESS = "0xCf7Ed3AccA5a467e9e704C703E8D87F634fB0Fc9";

// Backend
export const BACKEND_URL = "http://localhost:3001";

// Legacy/Deprecated (Kept for compatibility if needed, distinct)
export const VERCROW_ESCROW_ADDRESS = ""; 
