"use client";

import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { ethers } from "ethers";

interface DemoContextType {
    isDemoMode: boolean;
    toggleDemoMode: () => void;
    demoSellerAddress: string | null;
    demoSellerPrivateKey: string | null;
}

const DemoContext = createContext<DemoContextType | undefined>(undefined);

export function DemoProvider({ children }: { children: ReactNode }) {
    const [isDemoMode, setIsDemoMode] = useState(false);
    const [demoSellerAddress, setDemoSellerAddress] = useState<string | null>(null);
    const [demoSellerPrivateKey, setDemoSellerPrivateKey] = useState<string | null>(null);

    useEffect(() => {
        // Load preference
        const stored = localStorage.getItem("vercrow_demo_mode");
        if (stored === "true") setIsDemoMode(true);

        // Load or create demo seller
        const storedKey = localStorage.getItem("vercrow_demo_key");
        if (storedKey) {
            const wallet = new ethers.Wallet(storedKey);
            setDemoSellerPrivateKey(storedKey);
            setDemoSellerAddress(wallet.address);
        } else {
            const wallet = ethers.Wallet.createRandom();
            localStorage.setItem("vercrow_demo_key", wallet.privateKey);
            setDemoSellerPrivateKey(wallet.privateKey);
            setDemoSellerAddress(wallet.address);
        }
    }, []);

    const toggleDemoMode = () => {
        setIsDemoMode(prev => {
            const newVal = !prev;
            localStorage.setItem("vercrow_demo_mode", String(newVal));
            return newVal;
        });
    };

    return (
        <DemoContext.Provider value={{ isDemoMode, toggleDemoMode, demoSellerAddress, demoSellerPrivateKey }}>
            {children}
        </DemoContext.Provider>
    );
}

export function useDemo() {
    const context = useContext(DemoContext);
    if (context === undefined) {
        throw new Error("useDemo must be used within a DemoProvider");
    }
    return context;
}
