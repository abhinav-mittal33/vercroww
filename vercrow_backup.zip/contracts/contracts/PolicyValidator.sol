// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC721/ERC721.sol";
import "@openzeppelin/contracts/access/Ownable.sol";

/**
 * @title PolicyValidator
 * @dev Validates escrow intents and mints an NFT as proof of validation.
 *      This ensures that any VercrowEscrow contract created links back to a valid, policy-checked intent.
 */
contract PolicyValidator is ERC721, Ownable {
    uint256 private _nextTokenId;

    // --- Enums ---
    enum ConditionType {
        DELIVERY_CONFIRMED,
        QUALITY_SCORE,
        TEMPERATURE_RANGE,
        WEIGHT_VERIFIED
    }

    enum Operator {
        EQUALS,
        GREATER_THAN_EQUAL,
        LESS_THAN_EQUAL
    }

    // --- Structs ---
    struct Condition {
        ConditionType conditionType;
        Operator operator;
        uint256 value;
        bool required;
    }

    struct Intent {
        address creator;
        address beneficiary;
        uint256 amount;
        Condition[] conditions;
        uint256 deadline;
    }

    // --- Constants ---
    uint256 public constant MIN_AMOUNT = 0; // Allow any amount
    uint256 public constant MAX_AMOUNT = 1000000000 * 1e6; // 1 Billion USDC
    uint256 public constant MAX_CONDITIONS = 10;

    // --- State Variables ---
    mapping(bytes32 => Intent) private _intents; // Internal storage, getter returns decomposed data
    mapping(uint256 => bytes32) public tokenIdToIntentHash;

    // --- Events ---
    event IntentValidated(bytes32 indexed intentHash, uint256 indexed tokenId, address indexed creator);

    constructor() ERC721("Vercrow Intent", "VINT") Ownable(msg.sender) {}

    /**
     * @notice Validates an intent and mints an NFT to the creator if valid.
     * @param _intent The full intent structure proposed by the user.
     * @return intentHash The unique hash of the intent.
     * @return tokenId The ID of the minted NFT.
     */
    function validateAndMintIntent(Intent memory _intent) external returns (bytes32 intentHash, uint256 tokenId) {
        // 1. Validation Rules
        require(_intent.amount >= MIN_AMOUNT, "Amount too low");
        require(_intent.amount <= MAX_AMOUNT, "Amount too high");
        require(_intent.conditions.length > 0 && _intent.conditions.length <= MAX_CONDITIONS, "Invalid condition count");
        require(_intent.creator == msg.sender, "Creator mismatch");
        // require(_intent.beneficiary != _intent.creator, "Beneficiary cannot be creator"); // Allow self-escrow for demo
        require(_intent.deadline > block.timestamp, "Deadline must be in future");

        // 2. Generate Hash
        // We hash key fields to create a unique identifier for this specific deal structure
        // Note: For structs with dynamic arrays, abi.encode is needed.
        intentHash = keccak256(abi.encode(
            _intent.creator,
            _intent.beneficiary,
            _intent.amount,
            _intent.conditions, // This encodes the entire array
            _intent.deadline,
            block.timestamp // Include timestamp to allow identical intents to have different hashes if created at diff times? 
                            // Actually, standard practice is usually salt or nonce if we want uniqueness. 
                            // But for "Intent", if the details are identical, maybe the hash should be identical? 
                            // The user requested "Mint NFT", so each mint is unique. Let's add block.timestamp to salt it.
        ));

        // Ensure hash uniqueness (highly unlikely to collide unless in same block with same params, but good practice)
        // require(tokenIdToIntentHash[_nextTokenId + 1] == bytes32(0), "Hash collision"); // Logic slightly redundant if we trust keccak & nonce


        // 3. Storage
        // We cannot store the struct directly in a public mapping if it has nested dynamic arrays because 
        // Solidity can't auto-generate the getter for 'Condition[]'. 
        // So we use private mapping and a specific getter function if needed, or just rely on the hash for verification.
        // For this demo, let's store it so we can retrieve it.
        // _intents[intentHash] = _intent; // This copy is expensive but needed for "Provable audit trail"
        
        // Storing struct with nested array in mapping works in modern solidity, but you can't have a 'public' accessor for it automatically.
        // We will manually store it.
        Intent storage newIntent = _intents[intentHash];
        newIntent.creator = _intent.creator;
        newIntent.beneficiary = _intent.beneficiary;
        newIntent.amount = _intent.amount;
        newIntent.deadline = _intent.deadline;
        
        for(uint i = 0; i < _intent.conditions.length; i++) {
            newIntent.conditions.push(_intent.conditions[i]);
        }

        // 4. Mint NFT
        _nextTokenId++;
        tokenId = _nextTokenId;
        _mint(msg.sender, tokenId);

        tokenIdToIntentHash[tokenId] = intentHash;

        emit IntentValidated(intentHash, tokenId, msg.sender);

        return (intentHash, tokenId);
    }

    /**
     * @notice Helper to retrieve intent details by hash.
     */
    function getIntent(bytes32 _intentHash) external view returns (Intent memory) {
        return _intents[_intentHash];
    }
}
