// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/access/Ownable.sol";

contract AgentRegistry is Ownable {
    enum AgentRole { None, Delivery, Quality }

    mapping(address => AgentRole) public agents;

    event AgentRegistered(address indexed agent, AgentRole role);
    event AgentRemoved(address indexed agent);

    constructor() Ownable(msg.sender) {}

    function registerAgent(address _agent, AgentRole _role) external onlyOwner {
        require(_agent != address(0), "Invalid address");
        require(_role != AgentRole.None, "Invalid role");
        agents[_agent] = _role;
        emit AgentRegistered(_agent, _role);
    }

    function removeAgent(address _agent) external onlyOwner {
        delete agents[_agent];
        emit AgentRemoved(_agent);
    }

    function isDeliveryAgent(address _agent) external view returns (bool) {
        return agents[_agent] == AgentRole.Delivery;
    }

    function isQualityAgent(address _agent) external view returns (bool) {
        return agents[_agent] == AgentRole.Quality;
    }
}
