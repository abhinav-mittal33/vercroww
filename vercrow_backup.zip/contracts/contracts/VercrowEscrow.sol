// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import "./PolicyValidator.sol";

contract VercrowEscrow is ReentrancyGuard {
    using SafeERC20 for IERC20;

    // --- Enums ---
    enum EscrowState {
        PENDING,
        LOCKED,
        VERIFYING,
        RELEASED,
        DISPUTED,
        REFUNDED
    }

    // --- Structs ---
    struct ProofSubmission {
        uint8 conditionIndex;
        address source;
        uint256 value;
        bytes32 proofHash;
        uint256 timestamp;
        bool verified;
    }

    // --- State Variables ---
    address public creator;
    address public beneficiary;
    uint256 public amount;
    address public tokenAddress;
    
    EscrowState public state;
    bytes32 public intentHash;
    PolicyValidator public policyValidator;
    
    mapping(uint8 => ProofSubmission) public submittedProofs;
    uint8 public proofsSubmitted;
    uint256 public deadline;
    bool public disputeFlag;
    
    uint256 public totalConditions; // Need to know how many conditions to check for release
    
    // --- Authorization ---
    mapping(address => bool) public authorizedAgents;

    // --- Events ---
    event EscrowCreated(address indexed creator, address indexed beneficiary, uint256 amount);
    event EscrowFunded(uint256 amount);
    event ProofSubmitted(uint8 indexed conditionIndex, address indexed source, uint256 value);
    event FundsReleased(address indexed beneficiary, uint256 amount);
    event DisputeRaised(address indexed raiser, string reason);
    event AgentAuthorized(address indexed agent);
    event AgentRevoked(address indexed agent);

    // --- Modifiers ---
    modifier onlyCreator() {
        require(msg.sender == creator, "Only creator");
        _;
    }

    modifier onlyStakeholder() {
        require(msg.sender == creator || msg.sender == beneficiary, "Only stakeholder");
        _;
    }

    modifier onlyAuthorizedAgent() {
        require(authorizedAgents[msg.sender] || msg.sender == creator, "Not authorized agent");
        _;
    }

    // --- Functions ---

    /**
     * @notice Initializes the escrow. 
     * In a factory pattern, this might be called after deployment. 
     * For single deploy, constructor could work, but user prompt asked for 'initialize'.
     */
    function initialize(
        address _creator,
        address _beneficiary,
        uint256 _amount,
        bytes32 _intentHash,
        uint256 _deadline,
        address _policyValidator,
        address _tokenAddress
    ) external {
        require(creator == address(0), "Already initialized"); // Simple init check
        
        creator = _creator;
        beneficiary = _beneficiary;
        amount = _amount;
        intentHash = _intentHash;
        deadline = _deadline;
        policyValidator = PolicyValidator(_policyValidator);
        tokenAddress = _tokenAddress;
        
        state = EscrowState.PENDING;
        
        // Retrieve condition count from validator to know when we are done
        // Note: This requires the PolicyValidator to have a way to return struct or count. 
        // Our PolicyValidator stores private struct. We added 'getIntent'.
        PolicyValidator.Intent memory intent = policyValidator.getIntent(_intentHash);
        require(intent.amount == _amount, "Intent mismatch");
        totalConditions = intent.conditions.length;

        emit EscrowCreated(_creator, _beneficiary, _amount);
    }

    /**
     * @notice Creator funds the escrow, locking tokens.
     */
    function fundEscrow() external onlyCreator nonReentrant {
        require(state == EscrowState.PENDING, "Invalid state");
        
        // Transfer tokens from creator to this contract
        IERC20(tokenAddress).safeTransferFrom(msg.sender, address(this), amount);
        
        state = EscrowState.LOCKED;
        emit EscrowFunded(amount);
    }

    /**
     * @notice Submit a proof for a specific condition.
     * In a real system, 'source' would be verified against an authorized list (Oracle).
     */
    function submitProof(
        uint8 _conditionIndex,
        uint256 _value,
        bytes32 _proofHash
    ) external onlyAuthorizedAgent {
        require(state == EscrowState.LOCKED || state == EscrowState.VERIFYING, "Invalid state");
        require(!submittedProofs[_conditionIndex].verified, "Already verified");
        require(_conditionIndex < totalConditions, "Invalid condition index");

        // Store proof
        submittedProofs[_conditionIndex] = ProofSubmission({
            conditionIndex: _conditionIndex,
            source: msg.sender,
            value: _value,
            proofHash: _proofHash,
            timestamp: block.timestamp,
            verified: true
        });

        proofsSubmitted++;
        
        if (state == EscrowState.LOCKED) {
            state = EscrowState.VERIFYING;
        }

        emit ProofSubmitted(_conditionIndex, msg.sender, _value);
    }

    /**
     * @notice Release funds if all conditions are met and no dispute.
     */
    function release() external nonReentrant {
        require(state == EscrowState.VERIFYING || state == EscrowState.LOCKED, "Invalid state");
        require(!disputeFlag, "Disputed");
        require(proofsSubmitted >= totalConditions, "Conditions not met");

        // In a real system, we would check if the VALUES match the required conditions here.
        // For this prototype, we assume the specific 'submitProof' call implies validation 
        // by the agent (Oracle) against the intent conditions.
        
        state = EscrowState.RELEASED;
        IERC20(tokenAddress).safeTransfer(beneficiary, amount);
        
        emit FundsReleased(beneficiary, amount);
    }

    /**
     * @notice Rise a dispute to pause the escrow.
     */
    function raiseDispute(string memory _reason) external onlyStakeholder {
        require(state != EscrowState.RELEASED && state != EscrowState.REFUNDED, "Already finalized");
        
        disputeFlag = true;
        state = EscrowState.DISPUTED;
        
        emit DisputeRaised(msg.sender, _reason);
    }

    /**
     * @notice Authorize an agent to submit proofs
     */
    function setAuthorizedAgent(address _agent, bool _authorized) external onlyCreator {
        authorizedAgents[_agent] = _authorized;
        if (_authorized) {
            emit AgentAuthorized(_agent);
        } else {
            emit AgentRevoked(_agent);
        }
    }
}
