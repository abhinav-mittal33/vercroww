# Vercrow Smart Contracts 🛡️

Vercrow is an **Agentic Escrow Protocol** that secures real-world transactions using **Intent-Based NFTs** and **AI Oracles**.

## 🏗 Architecture

The system is composed of three core modular contracts:

### 1. `PolicyValidator.sol` (The Brain)
*   **Type**: ERC-721 (NFT)
*   **Role**: Intent Parser & Immutable Store.
*   **Logic**: 
    1.  Receives natural language intents parsed into structural conditions (e.g., "Must be > 5kg").
    2.  Validates these rules against protocol safety limits.
    3.  **Mints an Intent NFT**: This NFT represents the "Soul" of the deal. The conditions are hashed (`intentHash`) and stored immutably.
    4.  This decoupled design allows any frontend or agent to propose intents without deploying a full escrow first.

### 2. `VercrowEscrow.sol` (The Vault)
*   **Type**: Finite State Machine (FSM)
*   **Role**: Funds Custody & Execution.
*   **Logic**:
    *   **Initialization**: Linked to a specific `Intent NFT` hash. It respects *only* the conditions defined in that Intent.
    *   **State Machine**: `PENDING` -> `LOCKED` (Funds In) -> `VERIFYING` (Proofs In) -> `RELEASED` (Funds Out).
    *   **Security**: Implements `ReentrancyGuard` and `PullPayment` patterns.
    *   **Trust Model**: The contract does *not* trust the AI implicitly. It enforces that the *data* provided by the AI matches the *conditions* signed by the user.

### 3. `AgentRegistry.sol` (The Trust Network) - *Alpha*
*   **Role**: Identity Management for AI Agents.
*   **Logic**:
    *   Maintains a whitelist of approved "Oracle Agents" (e.g., FedEx API Agent, Vision AI Agent).
    *   Uses a **Staking Mechanism** (future scope) where agents stake tokens to slash if they provide bad data.

---

## 🔐 Security & Patterns

*   **Checks-Effects-Interactions**: Strictly followed to prevent reentrancy.
*   **Role-Based Access Control (RBAC)**: Distinct roles for `Creator`, `Beneficiary`, and `AuthorizedAgent`.
*   **Mock Tokens**: Includes `MockUSDC.sol` for consistent testing on testnets/localhost.

## 🚀 Deployment

```bash
# Deploy to Localhost
npx hardhat run scripts/deploy.js --network localhost
```

## 🧪 Testing

```bash
npx hardhat test
```
