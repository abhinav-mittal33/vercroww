const hre = require("hardhat");
const fs = require("fs");

async function main() {
    const [deployer] = await hre.ethers.getSigners();
    console.log("Deploying contracts with account:", deployer.address);

    // 1. Deploy MockUSDC
    const MockUSDC = await hre.ethers.getContractFactory("MockUSDC");
    const mockUSDC = await MockUSDC.deploy();
    await mockUSDC.waitForDeployment();
    const usdcAddress = await mockUSDC.getAddress();
    console.log("MockUSDC deployed to:", usdcAddress);

    // 2. Deploy AgentRegistry
    const AgentRegistry = await hre.ethers.getContractFactory("AgentRegistry");
    const registry = await AgentRegistry.deploy();
    await registry.waitForDeployment();
    const registryAddress = await registry.getAddress();
    console.log("AgentRegistry deployed to:", registryAddress);

    // 3. Deploy PolicyValidator
    const PolicyValidator = await hre.ethers.getContractFactory("PolicyValidator");
    const validator = await PolicyValidator.deploy();
    await validator.waitForDeployment();
    const validatorAddress = await validator.getAddress();
    console.log("PolicyValidator deployed to:", validatorAddress);

    // 4. Deploy VercrowEscrow
    const VercrowEscrow = await hre.ethers.getContractFactory("VercrowEscrow");
    const escrow = await VercrowEscrow.deploy();
    await escrow.waitForDeployment();
    const escrowAddress = await escrow.getAddress();
    console.log("VercrowEscrow deployed to:", escrowAddress);

    // 5. Setup Agents (Create random wallets for backend)
    const deliveryWallet = hre.ethers.Wallet.createRandom();
    const qualityWallet = hre.ethers.Wallet.createRandom();

    await registry.registerAgent(deliveryWallet.address, 1); // Delivery
    await registry.registerAgent(qualityWallet.address, 2); // Quality

    console.log("------------------------------------------------");
    console.log("AGENTS REGISTERED");
    console.log("Delivery Agent Address:", deliveryWallet.address);
    console.log("Delivery Agent Private Key:", deliveryWallet.privateKey);
    console.log("Quality Agent Address:", qualityWallet.address);
    console.log("Quality Agent Private Key:", qualityWallet.privateKey);
    console.log("------------------------------------------------");

    // Save details to a file for easy copying
    const details = {
        usdc: usdcAddress,
        registry: registryAddress,
        validator: validatorAddress,
        escrow: escrowAddress,
        deliveryAgent: {
            address: deliveryWallet.address,
            privateKey: deliveryWallet.privateKey
        },
        qualityAgent: {
            address: qualityWallet.address,
            privateKey: qualityWallet.privateKey
        }
    };

    fs.writeFileSync("deployment-details.json", JSON.stringify(details, null, 2));
}

main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
});
