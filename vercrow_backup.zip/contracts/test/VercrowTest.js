const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("VercrowEscrow", function () {
    let mockUSDC, registry, validator, escrow;
    let owner, buyer, seller, deliveryAgent, qualityAgent;

    before(async function () {
        [owner, buyer, seller, deliveryAgent, qualityAgent] = await ethers.getSigners();

        // Deploy MockUSDC
        const MockUSDC = await ethers.getContractFactory("MockUSDC");
        mockUSDC = await MockUSDC.deploy();
        await mockUSDC.waitForDeployment(); // Updated for Ethers v6

        // Deploy Registry
        const AgentRegistry = await ethers.getContractFactory("AgentRegistry");
        registry = await AgentRegistry.deploy();
        await registry.waitForDeployment();

        // Deploy Validator
        const PolicyValidator = await ethers.getContractFactory("PolicyValidator");
        validator = await PolicyValidator.deploy();
        await validator.waitForDeployment();

        // Deploy Escrow
        const VercrowEscrow = await ethers.getContractFactory("VercrowEscrow");
        escrow = await VercrowEscrow.deploy(
            await registry.getAddress(),
            await validator.getAddress()
        );
        await escrow.waitForDeployment();

        // Setup
        await registry.registerAgent(deliveryAgent.address, 1); // Delivery
        await registry.registerAgent(qualityAgent.address, 2); // Quality

        // Mint tokens to buyer
        await mockUSDC.mint(buyer.address, ethers.parseUnits("50000", 6));
    });

    it("Should execute full happy path", async function () {
        const amount = ethers.parseUnits("30000", 6);
        const item = "Books";
        const quantity = 30;
        const qualityThreshold = 85;
        const deliveryDays = 14;

        // 1. Create (Buyer)
        const tx = await escrow.connect(buyer).createEscrow(
            seller.address,
            await mockUSDC.getAddress(),
            amount,
            item,
            quantity,
            qualityThreshold,
            deliveryDays
        );
        const receipt = await tx.wait();

        // Parse event to get ID (assuming it's ID 0 for first test)
        const escrowId = 0;

        // 2. Approve (Seller)
        await escrow.connect(seller).approveEscrow(escrowId);

        // 3. Deposit (Buyer)
        await mockUSDC.connect(buyer).approve(await escrow.getAddress(), amount);
        await escrow.connect(buyer).deposit(escrowId);

        const escrowDataAfterDeposit = await escrow.escrows(escrowId);
        expect(escrowDataAfterDeposit.status).to.equal(2); // Funded

        // 4. Delivery (Agent)
        await escrow.connect(deliveryAgent).confirmDelivery(escrowId);

        // 5. Quality (Agent) - Score 90 (above 85)
        await escrow.connect(qualityAgent).submitQuality(escrowId, 90);

        // Check Final Status
        const escrowDataFinal = await escrow.escrows(escrowId);
        expect(escrowDataFinal.status).to.equal(5); // Settled
        expect(escrowDataFinal.payoutAmount).to.equal(amount);

        // Check Balances
        const sellerBalance = await mockUSDC.balanceOf(seller.address);
        expect(sellerBalance).to.equal(amount);
    });
});
