# 🦅 Vercrow: Agentic Escrow Protocol

**The First Policy-Gated Escrow System Secured by Intent NFTs.**

[![Watch the Demo](https://img.youtube.com/vi/placeholder/0.jpg)](INSERT_YOUR_VIDEO_LINK_HERE)

> **Hackathon Judges:** Please see the **Demo Video** above for the official preview. This prototype runs on a local Hardhat node for high-frequency testing.

---

## 💡 The Problem
Traditional escrow is manual, slow, and expensive.
Smart Contracts are secure but hard to use ("Code is Law" is scary).
**Vercrow bridges this gap using AI to translate "Natural Language" into "Immutable Code".**

## 🚀 Features
*   **NLP Intent Parsing**: Type "Release 500 USDC for hoodies" -> Get a Smart Contract.
*   **Intent NFTs (ERC-721)**: Every deal is minted as an NFT ("The Soul of the Deal").
*   **AI Oracle Network**: Autonomous Agents verify real-world proofs (Delivery/Quality) to trigger release.
*   **Zero-Trust Architecture**: Funds are held by the contract, not the AI.

## 🛠️ Stack
*   **Frontend**: Next.js 14, Tailwind, Framer Motion
*   **Blockchain**: Hardhat, Ethers.js v6
*   **AI**: Gemini Flash 1.5 (Mocked for Stability)
*   **Contracts**: OpenZeppelin v5 (ERC-20, ERC-721, ReentrancyGuard)

---

## 📦 How to Run
Prerequisites: Node.js, Metamask.

### 1. Start Support Chain
```bash
cd contracts
npx hardhat node
```
*Keep this terminal open.*

### 2. Deploy Contracts
```bash
cd contracts
npx hardhat run scripts/deploy.js --network localhost
```

### 3. Start App
```bash
cd frontend
npm run dev
```
Visit `http://localhost:3000`.

---
*Built with ❤️ for the Hackathon.*
